Runtime logs are written to the selected writable data directory.
Developed by Hjc
