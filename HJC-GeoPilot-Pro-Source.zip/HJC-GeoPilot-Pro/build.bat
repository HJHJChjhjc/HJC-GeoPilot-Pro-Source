@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    call setup.bat
    if errorlevel 1 goto failed
)
".venv\Scripts\python.exe" -m pip install -r requirements-dev.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pytest -q
if errorlevel 1 goto failed
set QT_QPA_PLATFORM=offscreen
".venv\Scripts\python.exe" app.py --smoke-test
if errorlevel 1 goto failed
set QT_QPA_PLATFORM=
".venv\Scripts\python.exe" -m PyInstaller hjc-geopilot.spec --clean --noconfirm
if errorlevel 1 goto failed
copy /y portable.flag "dist\HJC-GeoPilot-Pro\portable.flag" >nul
mkdir "dist\HJC-GeoPilot-Pro\examples" 2>nul
copy /y "routes\*" "dist\HJC-GeoPilot-Pro\examples\" >nul
set QT_QPA_PLATFORM=offscreen
start /wait "" "dist\HJC-GeoPilot-Pro\HJC-GeoPilot-Pro.exe" --smoke-test
if errorlevel 1 goto failed
set QT_QPA_PLATFORM=
powershell.exe -NoProfile -Command "Compress-Archive -Path 'dist\HJC-GeoPilot-Pro' -DestinationPath 'dist\HJC-GeoPilot-Pro-Portable.zip' -Force"
if errorlevel 1 goto failed
echo Build complete. See dist\HJC-GeoPilot-Pro-Portable.zip.
goto finish
:failed
echo Build failed. Check the error above and docs\WINDOWS.md.
:finish
echo.
echo Press any key to close this window.
pause >nul
endlocal
