import json
import uuid
import logging
from pathlib import Path
from backend.models import Preset
from backend.config_manager import atomic_json


class PresetManager:
    def __init__(self, folder: Path) -> None:
        self.folder = folder
        folder.mkdir(parents=True, exist_ok=True)

    def list(self, query: str = "", sort: str = "Name") -> list[tuple[Path, Preset]]:
        result = []
        for path in self.folder.glob("*.json"):
            try:
                p = self.load(path)
                if query.casefold() in (p.name + " " + p.notes).casefold():
                    result.append((path, p))
            except Exception:
                logging.getLogger(__name__).exception("Invalid preset: %s", path.name)
        result.sort(
            key=lambda item: (
                not item[1].favorite,
                item[1].created_at if sort == "Date" else item[1].name.casefold(),
            )
        )
        return result

    def load(self, path: Path) -> Preset:
        if path.stat().st_size > 20_000_000:
            raise ValueError("预设文件超过 20 MB")
        return Preset.parse(json.loads(path.read_text(encoding="utf-8-sig")))

    def save(self, preset: Preset, path: Path | None = None) -> Path:
        path = path or self.folder / f"{uuid.uuid4().hex}.json"
        data = preset.to_dict()
        Preset.parse(data)
        atomic_json(path, data)
        return path
