from __future__ import annotations
import asyncio
import importlib.metadata
import platform
import json
from dataclasses import dataclass
from backend.device_manager import DeviceManager


@dataclass
class Check:
    component: str
    status: str
    problem: str
    advice: str


async def subprocess_output(*args: str) -> str:
    process = await asyncio.create_subprocess_exec(
        *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    try:
        stdout, stderr = await asyncio.wait_for(process.communicate(), 15)
    except BaseException:
        process.kill()
        await process.wait()
        raise
    if process.returncode:
        raise RuntimeError(stderr.decode(errors="replace"))
    return stdout.decode("utf-8-sig", errors="replace").strip()


async def diagnose(manager: DeviceManager) -> list[Check]:
    checks = []
    try:
        version = importlib.metadata.version("pymobiledevice3")
        checks.append(
            Check(
                "pymobiledevice3",
                "PASS",
                version,
                "已固定已核查 API 的版本；升级后需重新测试。",
            )
        )
    except importlib.metadata.PackageNotFoundError:
        checks.append(Check("pymobiledevice3", "FAIL", "未安装", "运行 setup.bat"))
    if platform.system() == "Windows":
        try:
            command = "[Console]::OutputEncoding=[Text.UTF8Encoding]::new(); @(Get-PnpDevice -PresentOnly | Where-Object {$_.FriendlyName -match 'Apple.*(USB|Mobile|iPhone|iPad)'}) | Select-Object Status,FriendlyName | ConvertTo-Json -Compress"
            output = await subprocess_output("powershell.exe", "-NoProfile", "-Command", command)
            data = json.loads(output) if output else []
            items = [data] if isinstance(data, dict) else data
            ok = any(item.get("Status") == "OK" for item in items)
            checks.append(
                Check(
                    "USB Driver",
                    "PASS" if ok else "UNKNOWN",
                    output or "没有发现 Apple PnP 设备",
                    "请连接 USB，安装 Apple Devices / Apple Mobile Device 驱动；仅驱动状态不能证明 DVT 可用。",
                )
            )
        except Exception as e:
            checks.append(
                Check("USB Driver", "UNKNOWN", str(e), "在设备管理器检查 Apple USB 驱动。")
            )
    else:
        checks.append(
            Check(
                "USB Driver",
                "NOT TESTED",
                "当前不是 Windows",
                "Windows 驱动需要在目标电脑验证。",
            )
        )
    await manager.refresh()
    checks.append(
        Check(
            "USB discovery",
            "PASS" if manager.devices else "UNKNOWN",
            manager.usb_error or f"{len(manager.devices)} device(s)",
            "解锁、信任电脑、换数据线并检查 Apple Mobile Device 服务。",
        )
    )
    try:
        tunnels = await manager.services.tunnels()
        checks.append(
            Check(
                "tunneld",
                "PASS",
                f"{len(tunnels)} tunnel(s)",
                "零隧道时检查开发者模式、DDI、驱动与管理员权限。",
            )
        )
    except Exception as e:
        checks.append(
            Check(
                "tunneld",
                "UNAVAILABLE",
                f"{type(e).__name__}: {e}",
                "点击 Devices → Start tunneld；部分 USB DVT 设备不需要隧道。",
            )
        )
    for d in manager.devices.values():
        label = f"{d.name} [{d.udid[-6:]}]"
        checks.append(
            Check(
                "Developer Mode " + label,
                "PASS"
                if d.developer_mode == "Enabled"
                else "UNKNOWN"
                if d.developer_mode == "Unknown"
                else "FAIL",
                d.developer_mode,
                "如设备提供此选项，在设置 → 隐私与安全性中启用。",
            )
        )
        connected = d.udid in manager.sessions
        checks.append(
            Check(
                "DVT " + label,
                "PASS" if connected else "NOT TESTED",
                d.reason or d.connection,
                "连接设备会实际打开 DVT 和 LocationSimulation；失败时检查 Developer Disk Image。",
            )
        )
        checks.append(
            Check(
                "LocationSimulation " + label,
                "PASS" if connected else "NOT TESTED",
                d.location_service,
                "PASS 表示通道已打开；坐标是否实际生效仍需设备测试。",
            )
        )
    if not manager.devices:
        for component in ("Developer Mode", "DVT", "LocationSimulation"):
            checks.append(
                Check(
                    component,
                    "NOT TESTED",
                    "没有设备",
                    "连接实体 iPhone/iPad 后执行诊断。",
                )
            )
    return checks
