"""Validated domain objects, independent of Qt and iOS transports."""

from __future__ import annotations
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
import math
from typing import Any


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


@dataclass(frozen=True)
class Point:
    lat: float
    lon: float

    def __post_init__(self) -> None:
        if not math.isfinite(self.lat) or not -90 <= self.lat <= 90:
            raise ValueError("Latitude 必须在 -90 到 90 之间")
        if not math.isfinite(self.lon) or not -180 <= self.lon <= 180:
            raise ValueError("Longitude 必须在 -180 到 180 之间")

    @classmethod
    def parse(cls, value: dict[str, Any]) -> Point:
        return cls(float(value["lat"]), float(value.get("lon", value.get("lng"))))


@dataclass
class Route:
    name: str = "Untitled route"
    version: int = 1
    author: str = "Hjc"
    created_at: str = field(default_factory=utc_now)
    coordinate_system: str = "WGS84"
    points: list[Point] = field(default_factory=list)
    speed_profile: list[dict[str, float]] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)
    closed: bool = False

    def validate(self, runnable: bool = False) -> None:
        if self.coordinate_system != "WGS84":
            raise ValueError("仅接受 WGS84。GCJ-02 / BD-09 请先转换，避免地图偏移。")
        if not self.name.strip() or self.version != 1:
            raise ValueError("路线名称为空或文件版本不支持")
        if len(self.points) > 100000:
            raise ValueError("路线超过 100000 个点，请简化后导入")
        if runnable and len(self.points) < 2:
            raise ValueError("至少需要两个路线点")
        if not isinstance(self.metadata, dict) or not isinstance(self.speed_profile, list):
            raise ValueError("metadata 必须是对象，speed_profile 必须是数组")
        last = -1.0
        for segment in self.speed_profile:
            distance = float(segment["distance_m"])
            speed = float(segment["speed_ms"])
            if not math.isfinite(distance) or distance < 0 or distance <= last:
                raise ValueError("速度分段 distance_m 必须递增且非负")
            if not math.isfinite(speed) or not 0 < speed <= 100:
                raise ValueError("分段速度必须在 0 到 100 m/s 之间")
            last = distance

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        result = asdict(self)
        result["author"] = "Hjc"
        return result

    @classmethod
    def parse(cls, value: dict[str, Any]) -> Route:
        # Explicit legacy import; legacy input is assumed WGS84 and marked.
        legacy = "coordinates" in value
        route = cls(
            name=str(value.get("name", value.get("route_name", "Imported route"))),
            version=int(value.get("version", 1)),
            author=str(value.get("author", "Hjc")),
            created_at=str(value.get("created_at", utc_now())),
            coordinate_system=str(value.get("coordinate_system", "WGS84")),
            points=[Point.parse(p) for p in value.get("points", value.get("coordinates", []))],
            speed_profile=value.get("speed_profile", []),
            metadata=value.get("metadata", {}),
            closed=bool(value.get("closed", False)),
        )
        if legacy:
            route.metadata["legacy_import_assumed_wgs84"] = True
        route.validate()
        return route


@dataclass
class DeviceInfo:
    udid: str
    name: str = "iOS device"
    model: str = "Unknown"
    ios: str = "Unknown"
    usb: bool = True
    developer_mode: str = "Unknown"
    connection: str = "Discovered"
    tunnel: str = "Unknown"
    location_service: str = "Not connected"
    reason: str = ""


@dataclass
class Telemetry:
    point: Point
    speed_ms: float = 0.0
    distance_m: float = 0.0
    remaining_m: float = 0.0
    elapsed_s: float = 0.0
    eta_s: float = 0.0
    point_index: int = 0
    progress: float = 0.0
    status: str = "Idle"
    lap: int = 1


@dataclass
class Preset:
    name: str
    center: Point
    route: Route
    boundary: list[Point] = field(default_factory=list)
    zoom: int = 17
    map_type: str = "Normal"
    created_at: str = field(default_factory=utc_now)
    notes: str = ""
    favorite: bool = False
    author: str = "Hjc"

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"author": "Hjc"}

    @classmethod
    def parse(cls, data: dict[str, Any]) -> Preset:
        p = cls(
            str(data["name"]),
            Point.parse(data["center"]),
            Route.parse(data["route"]),
            [Point.parse(p) for p in data.get("boundary", [])],
            int(data.get("zoom", 17)),
            str(data.get("map_type", "Normal")),
            str(data.get("created_at", utc_now())),
            str(data.get("notes", "")),
            bool(data.get("favorite", False)),
        )
        if (
            not p.name.strip()
            or not 2 <= p.zoom <= 19
            or p.map_type not in ("Normal", "Satellite", "Route")
        ):
            raise ValueError("场地预设字段无效")
        return p
