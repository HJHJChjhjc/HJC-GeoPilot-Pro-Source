from __future__ import annotations
import json
import logging
import os
import sys
import tempfile
from pathlib import Path
from typing import Any
from backend.models import Point

RESOURCE_ROOT = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[1]))


def data_root() -> Path:
    explicit = os.environ.get("HJC_DATA_DIR")
    base = Path(sys.executable).parent if getattr(sys, "frozen", False) else RESOURCE_ROOT
    if explicit:
        return Path(explicit).expanduser().resolve()
    if (base / "portable.flag").exists():
        return base / "data"
    return (
        Path(os.environ.get("LOCALAPPDATA", Path.home() / ".local" / "share")) / "HJC-GeoPilot-Pro"
    )


def atomic_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix=path.name, suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, allow_nan=False)
            f.flush()
            os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        if Path(temp).exists():
            Path(temp).unlink()


DEFAULTS: dict[str, Any] = {
    "version": 1,
    "author": "Hjc",
    "theme": "System",
    "window": [1280, 840],
    "last_device": "",
    "map_center": {"lat": 28.68, "lon": 115.98},
    "zoom": 16,
    "map_type": "Normal",
    "speed_unit": "m/s",
    "speed_ms": 2.8,
    "refresh_hz": 5,
    "recent_routes": [],
    "recent_presets": [],
    "auto_refresh": True,
    "restore_workspace": True,
}


class ConfigManager:
    def __init__(self, root: Path | None = None) -> None:
        self.root = root or data_root()
        for folder in ("routes", "configs", "logs", "cache"):
            (self.root / folder).mkdir(parents=True, exist_ok=True)
        self.path = self.root / "settings.json"
        self.warning = ""
        self.data = self.load()

    @staticmethod
    def validate(data: dict[str, Any]) -> dict[str, Any]:
        d = json.loads(json.dumps(DEFAULTS))
        d.update(data)
        d["author"] = "Hjc"
        if d["version"] != 1:
            raise ValueError("配置版本不支持")
        for key in ("auto_refresh", "restore_workspace"):
            if not isinstance(d[key], bool):
                raise ValueError(f"{key} 必须为布尔值")
        for key in ("recent_routes", "recent_presets"):
            if not isinstance(d[key], list) or not all(isinstance(x, str) for x in d[key]):
                raise ValueError("最近文件列表无效")
        if d.get("manual_position"):
            Point.parse(d["manual_position"])
        if d.get("saved_position"):
            Point.parse(d["saved_position"])
        if d["theme"] not in ("System", "Light", "Dark"):
            raise ValueError("无效主题")
        if d["map_type"] not in ("Normal", "Satellite", "Route"):
            raise ValueError("无效地图类型")
        Point.parse(d["map_center"])
        if not 2 <= int(d["zoom"]) <= 19:
            raise ValueError("无效地图缩放")
        if not 0.1 <= float(d["speed_ms"]) <= 100 or not 1 <= float(d["refresh_hz"]) <= 20:
            raise ValueError("速度或刷新率无效")
        if len(d["window"]) != 2 or not all(600 <= int(x) <= 8000 for x in d["window"]):
            raise ValueError("无效窗口大小")
        if d["speed_unit"] not in ("m/s", "km/h", "min/km"):
            raise ValueError("无效速度单位")
        d["speed_ms"] = float(d["speed_ms"])
        d["refresh_hz"] = float(d["refresh_hz"])
        d["zoom"] = int(d["zoom"])
        d["window"] = [int(v) for v in d["window"]]
        return d

    def load(self) -> dict[str, Any]:
        try:
            return (
                self.validate(json.loads(self.path.read_text(encoding="utf-8")))
                if self.path.exists()
                else self.validate({})
            )
        except (ValueError, TypeError, KeyError, OSError) as e:
            self.warning = f"配置损坏，已恢复默认：{e}"
            logging.getLogger(__name__).warning(self.warning)
            if self.path.exists():
                import shutil

                shutil.copy2(self.path, self.path.with_suffix(".invalid.json"))
            return self.validate({})

    def save(self) -> None:
        self.data = self.validate(self.data)
        atomic_json(self.path, self.data)

    def recent(self, field: str, path: str) -> None:
        items = self.data[field]
        self.data[field] = [path] + [x for x in items if x != path][:19]
