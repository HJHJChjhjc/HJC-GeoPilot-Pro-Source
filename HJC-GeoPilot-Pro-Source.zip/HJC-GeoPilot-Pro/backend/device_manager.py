from __future__ import annotations
import asyncio
import logging
from dataclasses import dataclass
from typing import Any
from backend.ios_services import IOSServices, LocationSession
from backend.models import DeviceInfo

log = logging.getLogger(__name__)


@dataclass
class DeviceSession:
    info: DeviceInfo
    provider: Any
    location: LocationSession


class DeviceManager:
    def __init__(self, services: IOSServices | None = None) -> None:
        self.services = services or IOSServices()
        self.devices: dict[str, DeviceInfo] = {}
        self.sessions: dict[str, DeviceSession] = {}
        self.lock = asyncio.Lock()
        self.refresh_lock = asyncio.Lock()
        self.usb_error = ""

    async def refresh(self) -> list[DeviceInfo]:
        async with self.refresh_lock:
            try:
                usb = await self.services.usb_devices()
                self.usb_error = ""
            except Exception as e:
                self.usb_error = f"USB 检测失败：{type(e).__name__}: {e}"
                log.warning(self.usb_error)
                usb = []
            try:
                tunnels = await self.services.tunnels()
            except Exception:
                tunnels = {}
            found: dict[str, DeviceInfo] = {}
            for device in usb:
                if not device.is_usb:
                    continue
                udid = device.serial
                info = self.devices.get(udid, DeviceInfo(udid))
                info.usb = True
                info.tunnel = "Ready" if udid in tunnels else "Unavailable"
                if udid not in self.sessions:
                    client = None
                    try:
                        client = await self.services.lockdown(udid)
                        values = client.all_values
                        info.name = str(values.get("DeviceName", "iOS device"))
                        info.model = str(values.get("ProductType", "Unknown"))
                        info.ios = str(values.get("ProductVersion", "Unknown"))
                        try:
                            mode = await asyncio.wait_for(client.get_developer_mode_status(), 3)
                            info.developer_mode = "Enabled" if mode else "Disabled"
                        except Exception as e:
                            info.developer_mode = "Unknown"
                            info.reason = f"开发者模式查询不可用：{type(e).__name__}"
                        info.connection = "Discovered"
                    except Exception as e:
                        info.reason = f"配对/读取失败：{type(e).__name__}: {e}"
                        info.connection = "Locked / untrusted"
                    finally:
                        if client:
                            await client.close()
                found[udid] = info
            for udid, session in list(self.sessions.items()):
                if udid not in found:
                    session.info.usb = False
                    session.info.connection = "USB missing"
                    session.info.reason = "USB 已断开；停止模拟并重新连接。"
                    found[udid] = session.info
            self.devices = found
            return list(found.values())

    async def connect(self, udid: str) -> DeviceSession:
        async with self.lock:
            if udid in self.sessions:
                return self.sessions[udid]
            info = self.devices.get(udid)
            if not info:
                raise ValueError("请先刷新并选择设备")
            errors: list[str] = []
            # Probe direct DVT, then tunnel DVT; the dependency selects the service.
            for transport in ("USB", "Tunnel"):
                provider = None
                try:
                    provider = await (
                        self.services.lockdown(udid)
                        if transport == "USB"
                        else self.services.remote(udid)
                    )
                    location = await asyncio.wait_for(self.services.location(provider), 15)
                    info.connection = f"Connected ({transport})"
                    info.location_service = "Ready"
                    info.reason = ""
                    session = DeviceSession(info, provider, location)
                    self.sessions[udid] = session
                    log.info("DVT LocationSimulation connected via %s", transport)
                    return session
                except BaseException as e:
                    errors.append(f"{transport}: {type(e).__name__}: {e}")
                    if provider:
                        try:
                            await provider.close()
                        except Exception:
                            log.exception("Provider cleanup failed")
                    if isinstance(e, asyncio.CancelledError):
                        raise
            info.connection = "Failed"
            info.location_service = "Unavailable"
            info.reason = (
                "\n".join(errors)
                + "\n请检查信任、开发者模式、Developer Disk Image 与 tunneld；该设备能力未确认。"
            )
            raise ConnectionError(info.reason)

    async def disconnect(self, udid: str) -> None:
        async with self.lock:
            session = self.sessions.pop(udid, None)
            if not session:
                return
            try:
                await session.location.close()
            finally:
                await session.provider.close()
                session.info.connection = "Disconnected"
                session.info.location_service = "Not connected"

    async def close(self) -> None:
        for udid in list(self.sessions):
            try:
                await self.disconnect(udid)
            except Exception:
                log.exception("Device close failed")
