from __future__ import annotations
import asyncio
import time
import math
from collections.abc import Callable
from dataclasses import dataclass, field
import logging
from backend.models import Point, Telemetry, Route
from backend.movement_engine import MovementEngine
from backend.location_service import LocationService


@dataclass
class RunSession:
    engine: MovementEngine
    task: asyncio.Task | None = None
    trail: list[Point] = field(default_factory=list)
    error: str = ""


class SimulationService:
    def __init__(
        self,
        location: LocationService,
        on_update: Callable[[str, Telemetry], None],
        on_error: Callable[[str, str], None],
    ) -> None:
        self.location = location
        self.on_update = on_update
        self.on_error = on_error
        self.runs: dict[str, RunSession] = {}
        self.locks: dict[str, asyncio.Lock] = {}

    async def start(
        self,
        key: str,
        route: Route,
        speed: float,
        loops: int,
        index: int,
        reverse: bool,
        hz: float,
    ) -> None:
        async with self.locks.setdefault(key, asyncio.Lock()):
            if not math.isfinite(hz) or not 1 <= hz <= 20:
                raise ValueError("刷新率必须在 1–20 Hz 之间")
            if key != "preview" and key not in self.location.manager.sessions:
                raise ConnectionError("先连接设备，或者选择 Offline preview")
            await self._stop_unlocked(key)
            engine = await asyncio.to_thread(MovementEngine, route, speed, loops, index, reverse)
            run = RunSession(engine)
            self.runs[key] = run
            run.engine.resume()
            run.task = asyncio.create_task(self._loop(key, run, hz))

    async def _loop(self, key: str, run: RunSession, hz: float) -> None:
        last = time.monotonic()
        try:
            while run.engine.status not in ("Stopped", "Completed"):
                now = time.monotonic()
                dt = now - last
                last = now
                telemetry = run.engine.step(dt)
                if run.engine.status == "Running" or telemetry.status == "Completed":
                    if key != "preview":
                        await self.location.set(key, telemetry.point)
                    run.trail.append(telemetry.point)
                    if len(run.trail) > 15000:
                        run.trail = run.trail[::2]
                self.on_update(key, telemetry)
                await asyncio.sleep(max(0, 1 / hz - (time.monotonic() - now)))
        except asyncio.CancelledError:
            raise
        except Exception as e:
            run.error = f"{type(e).__name__}: {e}"
            run.engine.stop()
            logging.getLogger(__name__).exception("Simulation failed")
            self.on_error(key, run.error)
        finally:
            if key != "preview":
                try:
                    await self.location.clear(key)
                except Exception as e:
                    logging.getLogger(__name__).exception("Unable to clear simulated GPS")
                    self.on_error(key, f"无法恢复真实 GPS：{e}。请重新连接并点击 Restore GPS。")
            self.on_update(key, run.engine.snapshot())

    async def stop(self, key: str) -> None:
        async with self.locks.setdefault(key, asyncio.Lock()):
            await self._stop_unlocked(key)

    async def _stop_unlocked(self, key: str) -> None:
        run = self.runs.get(key)
        if run:
            run.engine.stop()
            if run.task and not run.task.done():
                run.task.cancel()
                try:
                    await run.task
                except asyncio.CancelledError:
                    pass

    def pause(self, key: str) -> None:
        if key in self.runs:
            self.runs[key].engine.pause()

    def resume(self, key: str) -> None:
        if key in self.runs:
            self.runs[key].engine.resume()

    def seek(self, key: str, index: int) -> None:
        if key not in self.runs:
            raise ValueError("尚未运行路线")
        self.runs[key].engine.seek(index)

    async def close(self) -> None:
        await asyncio.gather(*(self.stop(key) for key in list(self.runs)))
