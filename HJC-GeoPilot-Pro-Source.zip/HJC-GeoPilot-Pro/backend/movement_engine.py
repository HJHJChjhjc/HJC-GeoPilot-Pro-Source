"""Deterministic distance-based movement; no sleeps, Qt, USB, or random spoofing."""

from __future__ import annotations
import math
import numpy as np
from backend.models import Route, Telemetry
from backend.route_engine import RoutePath


class MovementEngine:
    def __init__(
        self,
        route: Route,
        speed_ms: float = 2.8,
        loops: int = 1,
        start_index: int = 0,
        reverse: bool = False,
        acceleration: float = 1.5,
    ) -> None:
        if not math.isfinite(speed_ms) or not 0.1 <= speed_ms <= 100 or not 1 <= loops <= 10000:
            raise ValueError("速度/圈数超出范围")
        self.path = RoutePath(route)
        self.closed = route.closed
        self.profile = route.speed_profile
        if not 0 <= start_index < len(route.points):
            raise ValueError("起点索引无效")
        self.reverse = reverse
        self.base_speed = speed_ms
        self.acceleration = acceleration
        position = self.path.point_distance(
            len(route.points) - 1 - start_index if reverse else start_index
        )
        self.start = self.path.length - position if reverse else position
        self.cursor = self.start
        self.total = self.path.length * loops
        self.completed = 0.0
        self.elapsed = 0.0
        self.speed = speed_ms
        self.status = "Ready"
        self.loops = loops
        self.seek_offset = 0.0
        # Closed routes perform N complete laps from arbitrary point.
        # Open routes perform the remainder first, then ping-pong without teleport.
        self.end = self.start + self.total if self.closed else self.total

    def pause(self) -> None:
        if self.status == "Running":
            self.status = "Paused"

    def resume(self) -> None:
        if self.status in ("Paused", "Ready"):
            self.status = "Running"

    def stop(self) -> None:
        self.status = "Stopped"
        self.speed = 0

    def path_position(self) -> tuple[float, int]:
        lap = max(0, int(self.cursor / self.path.length))
        d = self.cursor % self.path.length
        if not self.closed and (lap % 2):
            d = self.path.length - d
        if not self.closed and self.cursor >= self.end:
            d = self.path.length if (self.loops % 2) else 0
        if self.reverse:
            d = self.path.length - d
        return d, min(self.loops, lap + 1)

    def target_speed(self, d: float) -> float:
        if not self.profile:
            return self.base_speed
        return float(
            np.interp(
                d,
                [float(s["distance_m"]) for s in self.profile],
                [float(s["speed_ms"]) for s in self.profile],
            )
        )

    def seek(self, index: int) -> None:
        d = self.path.point_distance(index)
        if self.reverse:
            d = self.path.length - d
        lap = int(self.cursor / self.path.length)
        if not self.closed and lap % 2:
            d = self.path.length - d
        self.cursor = min(self.end, lap * self.path.length + d)
        # Seek is relocation; it is deliberately excluded from travelled distance.

    def step(self, dt: float) -> Telemetry:
        if not math.isfinite(dt) or dt < 0:
            raise ValueError("时间增量无效")
        if self.status == "Running":
            d, _ = self.path_position()
            target = self.target_speed(d)
            change = max(
                -self.acceleration * dt,
                min(self.acceleration * dt, target - self.speed),
            )
            previous = self.speed
            self.speed += change
            travel = min(self.end - self.cursor, max(0, (previous + self.speed) / 2 * dt))
            self.cursor += travel
            self.completed += travel
            self.elapsed += dt
            if self.cursor >= self.end - 1e-8:
                self.status = "Completed"
        return self.snapshot()

    def snapshot(self) -> Telemetry:
        d, lap = self.path_position()
        point, index = self.path.at(d)
        remaining = max(0, self.end - self.cursor)
        speed = self.speed if self.status == "Running" else 0.0
        return Telemetry(
            point,
            speed,
            self.completed,
            remaining,
            self.elapsed,
            remaining / max(0.1, self.target_speed(d)),
            index,
            max(0, min(1, (self.cursor - self.start) / max(1e-8, self.end - self.start))),
            self.status,
            lap,
        )
