from pathlib import Path
import json
from xml.etree.ElementTree import Element, SubElement, tostring
from defusedxml import ElementTree as SafeET
from backend.models import Route, Point
from backend.config_manager import atomic_json


class RouteManager:
    def load(self, path: Path) -> Route:
        if path.stat().st_size > 20_000_000:
            raise ValueError("文件超过 20 MB，请简化路线")
        if path.suffix.lower() == ".json":
            return Route.parse(json.loads(path.read_text(encoding="utf-8-sig")))
        if path.suffix.lower() != ".gpx":
            raise ValueError("仅支持 JSON 和 GPX")
        root = SafeET.parse(path).getroot()

        def tag(node):
            return node.tag.split("}")[-1]

        name = next((n.text for n in root.iter() if tag(n) == "name" and n.text), path.stem)
        # Prefer tracks, then routes, then waypoints. Do not mix independent types.
        chosen = []
        for kind in ("trkpt", "rtept", "wpt"):
            chosen = [n for n in root.iter() if tag(n) == kind]
            if chosen:
                break
        segments = [n for n in root.iter() if tag(n) == "trkseg"]
        if len(segments) > 1:
            raise ValueError("GPX 包含多段轨迹，请分段导入，避免把断点连成直线")
        points = [Point(float(n.attrib["lat"]), float(n.attrib["lon"])) for n in chosen]
        if not points:
            raise ValueError("GPX 没有轨迹点")
        closed = len(points) > 2 and points[0] == points[-1]
        if closed:
            points.pop()
        route = Route(name=name, points=points, closed=closed, metadata={"source": path.name})
        route.validate()
        return route

    def save(self, path: Path, route: Route) -> None:
        route.validate()
        if path.suffix.lower() == ".json":
            atomic_json(path, route.to_dict())
            return
        if path.suffix.lower() != ".gpx":
            raise ValueError("文件扩展名必须是 .json 或 .gpx")
        root = Element(
            "gpx",
            {
                "xmlns": "http://www.topografix.com/GPX/1/1",
                "version": "1.1",
                "creator": "Hjc",
            },
        )
        meta = SubElement(root, "metadata")
        SubElement(meta, "name").text = route.name
        SubElement(SubElement(meta, "author"), "name").text = "Hjc"
        track = SubElement(root, "trk")
        SubElement(track, "name").text = route.name
        seg = SubElement(track, "trkseg")
        points = route.points + ([route.points[0]] if route.closed and route.points else [])
        for p in points:
            SubElement(seg, "trkpt", {"lat": f"{p.lat:.10f}", "lon": f"{p.lon:.10f}"})
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(
            b'<?xml version="1.0" encoding="UTF-8"?>\n' + tostring(root, encoding="utf-8")
        )
