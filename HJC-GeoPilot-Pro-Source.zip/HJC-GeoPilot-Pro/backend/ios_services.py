"""Real pymobiledevice3 11.21 adapters. No iOS version-number assumptions."""

from __future__ import annotations
import asyncio
from contextlib import AsyncExitStack
from typing import Any
import httpx
from backend.models import Point


class IOSServices:
    async def usb_devices(self) -> list[Any]:
        from pymobiledevice3.usbmux import list_devices

        return await asyncio.wait_for(list_devices(), 6)

    async def lockdown(self, udid: str) -> Any:
        from pymobiledevice3.lockdown import create_using_usbmux

        return await asyncio.wait_for(
            create_using_usbmux(serial=udid, connection_type="USB", pair_timeout=8), 12
        )

    async def tunnels(self) -> dict[str, Any]:
        # get_tunneld_devices in the dependency contains synchronous requests.get.
        # Use its documented HTTP response shape with an async client instead.
        async with httpx.AsyncClient(timeout=3, trust_env=False) as client:
            response = await client.get("http://127.0.0.1:49151/")
            response.raise_for_status()
            data = response.json()
        if not isinstance(data, dict):
            raise ValueError("tunneld 返回格式无效")
        return data

    async def remote(self, udid: str) -> Any:
        from pymobiledevice3.remote.remote_service_discovery import (
            RemoteServiceDiscoveryService,
        )

        details = (await self.tunnels()).get(udid, [])
        errors: list[str] = []
        for detail in details:
            rsd = RemoteServiceDiscoveryService(
                (detail["tunnel-address"], detail["tunnel-port"]),
                name=detail["interface"],
            )
            try:
                await asyncio.wait_for(rsd.connect(), 10)
                return rsd
            except BaseException as e:
                await rsd.close()
                if isinstance(e, asyncio.CancelledError):
                    raise
                errors.append(str(e))
        raise ConnectionError(
            "设备未提供可用隧道。启动 tunneld、解锁并信任电脑。" + "; ".join(errors)
        )

    async def location(self, provider: Any) -> LocationSession:
        session = LocationSession(provider)
        await session.open()
        return session


class LocationSession:
    def __init__(self, provider: Any) -> None:
        self.provider = provider
        self.stack = AsyncExitStack()
        self.channel: Any = None
        self.lock = asyncio.Lock()

    async def open(self) -> None:
        from pymobiledevice3.services.dvt.instruments.dvt_provider import DvtProvider
        from pymobiledevice3.services.dvt.instruments.location_simulation import (
            LocationSimulation,
        )

        try:
            dvt = await self.stack.enter_async_context(DvtProvider(self.provider))
            self.channel = await self.stack.enter_async_context(LocationSimulation(dvt))
        except BaseException:
            await self.stack.aclose()
            raise

    async def set(self, point: Point) -> None:
        async with self.lock:
            await asyncio.wait_for(self.channel.set(point.lat, point.lon), 5)

    async def clear(self) -> None:
        async with self.lock:
            await asyncio.wait_for(self.channel.clear(), 5)

    async def close(self) -> None:
        try:
            await self.clear()
        finally:
            await self.stack.aclose()
