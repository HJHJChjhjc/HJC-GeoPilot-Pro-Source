from __future__ import annotations
from bisect import bisect_right
import copy
import numpy as np
from scipy.interpolate import CubicSpline
from backend.models import Point, Route
from backend.geometry import distance, interpolate, LocalENU


class RoutePath:
    def __init__(self, route: Route) -> None:
        route.validate(True)
        self.points = [route.points[0]]
        self.source_indices = [0]
        self.original_distances = [0.0]
        original_distance = 0.0
        # Remove zero-length segments so binary search never divides by zero.
        for i, p in enumerate(route.points[1:], 1):
            segment = distance(self.points[-1], p)
            if segment > 1e-5:
                self.points.append(p)
                self.source_indices.append(i)
                original_distance += segment
            self.original_distances.append(original_distance)
        if route.closed and distance(self.points[-1], self.points[0]) > 1e-5:
            self.points.append(self.points[0])
            self.source_indices.append(0)
        if len(self.points) < 2:
            raise ValueError("路线全部是重复位置")
        self.cumulative = [0.0]
        for a, b in zip(self.points, self.points[1:]):
            self.cumulative.append(self.cumulative[-1] + distance(a, b))
        self.length = self.cumulative[-1]

    def at(self, meters: float) -> tuple[Point, int]:
        d = max(0, min(self.length, meters))
        i = min(len(self.points) - 2, max(0, bisect_right(self.cumulative, d) - 1))
        f = (d - self.cumulative[i]) / (self.cumulative[i + 1] - self.cumulative[i])
        return interpolate(self.points[i], self.points[i + 1], f), self.source_indices[i]

    def point_distance(self, index: int) -> float:
        if not 0 <= index < len(self.original_distances):
            raise ValueError("点超出路线范围")
        # Duplicate input points share the previous arc-length position.
        return self.original_distances[index]


def smooth(route: Route, spacing: float = 1.0) -> Route:
    path = RoutePath(route)
    if len(path.points) < 3:
        return copy.deepcopy(route)
    if path.length > 20000:
        raise ValueError("Spline 使用局部 ENU，限 20 km；长路线请用 Linear")
    origin = LocalENU(path.points[0])
    xy = np.array([origin.forward(p)[:2] for p in path.points])
    spline = CubicSpline(
        path.cumulative, xy, axis=0, bc_type="periodic" if route.closed else "natural"
    )
    count = min(20000, max(len(xy), int(path.length / spacing) + 1))
    ds = np.linspace(0, path.length, count, endpoint=not route.closed)
    result = copy.deepcopy(route)
    result.points = [origin.inverse(float(x), float(y)) for x, y in spline(ds)]
    result.metadata["smoothing"] = "CubicSpline ENU (may overshoot; inspect map before use)"
    return result


class RouteHistory:
    def __init__(self, route: Route) -> None:
        self.current = copy.deepcopy(route)
        self.undo_stack: list[Route] = []
        self.redo_stack: list[Route] = []

    def commit(self, route: Route) -> Route:
        route.validate()
        self.undo_stack.append(copy.deepcopy(self.current))
        self.undo_stack = self.undo_stack[-60:]
        self.current = copy.deepcopy(route)
        self.redo_stack.clear()
        return self.current

    def undo(self) -> Route:
        if self.undo_stack:
            self.redo_stack.append(self.current)
            self.current = self.undo_stack.pop()
        return self.current

    def redo(self) -> Route:
        if self.redo_stack:
            self.undo_stack.append(self.current)
            self.current = self.redo_stack.pop()
        return self.current
