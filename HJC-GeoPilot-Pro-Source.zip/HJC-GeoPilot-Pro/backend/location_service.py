"""Coordinates are serialized per device by LocationSession; UI never handles DVT."""

from backend.device_manager import DeviceManager
from backend.models import Point


class LocationService:
    def __init__(self, manager: DeviceManager) -> None:
        self.manager = manager
        self.positions: dict[str, Point] = {}

    async def set(self, udid: str, point: Point) -> None:
        if udid not in self.manager.sessions:
            raise ConnectionError("设备未连接定位模拟服务")
        await self.manager.sessions[udid].location.set(point)
        self.positions[udid] = point

    async def clear(self, udid: str) -> None:
        if udid in self.manager.sessions:
            await self.manager.sessions[udid].location.clear()
        self.positions.pop(udid, None)
