"""WGS84 ↔ ECEF ↔ local East/North/Up geometry.

PROJ's geocentric transformation and an orthonormal tangent basis avoid
latitude-dependent degree arithmetic. Shape size <= 20 km; distance uses Geod.
"""

from __future__ import annotations
import math
import numpy as np
from pyproj import Transformer, Geod
from backend.models import Point

GEOD = Geod(ellps="WGS84")
TO_ECEF = Transformer.from_crs("EPSG:4979", "EPSG:4978", always_xy=True)
FROM_ECEF = Transformer.from_crs("EPSG:4978", "EPSG:4979", always_xy=True)


class LocalENU:
    def __init__(self, origin: Point) -> None:
        self.origin = origin
        self.xyz = np.array(TO_ECEF.transform(origin.lon, origin.lat, 0))
        lon, lat = math.radians(origin.lon), math.radians(origin.lat)
        self.rotation = np.array(
            [
                [-math.sin(lon), math.cos(lon), 0],
                [
                    -math.sin(lat) * math.cos(lon),
                    -math.sin(lat) * math.sin(lon),
                    math.cos(lat),
                ],
                [
                    math.cos(lat) * math.cos(lon),
                    math.cos(lat) * math.sin(lon),
                    math.sin(lat),
                ],
            ]
        )

    def forward(self, point: Point) -> tuple[float, float, float]:
        xyz = np.array(TO_ECEF.transform(point.lon, point.lat, 0))
        return tuple(float(v) for v in self.rotation @ (xyz - self.xyz))

    def inverse(self, east: float, north: float, up: float = 0) -> Point:
        xyz = self.xyz + self.rotation.T @ np.array([east, north, up])
        lon, lat, _ = FROM_ECEF.transform(*xyz)
        return Point(lat, lon)


def distance(a: Point, b: Point) -> float:
    return float(GEOD.inv(a.lon, a.lat, b.lon, b.lat)[2])


def interpolate(a: Point, b: Point, fraction: float) -> Point:
    azi, _, length = GEOD.inv(a.lon, a.lat, b.lon, b.lat)
    lon, lat, _ = GEOD.fwd(a.lon, a.lat, azi, length * max(0, min(1, fraction)))
    return Point(lat, lon)


def offset(point: Point, east: float, north: float) -> Point:
    return LocalENU(point).inverse(east, north)


def transform(
    points: list[Point], origin: Point, destination: Point, angle: float = 0
) -> list[Point]:
    before, after = LocalENU(origin), LocalENU(destination)
    theta = math.radians(angle)
    c, s = math.cos(theta), math.sin(theta)
    result = []
    for point in points:
        x, y, z = before.forward(point)
        result.append(after.inverse(c * x - s * y, s * x + c * y, z))
    return result


def shape(
    center: Point,
    kind: str,
    long_axis: float,
    short_axis: float,
    angle: float = 0,
    straight: float = 84.39,
    radius: float = 36.8,
    samples: int = 360,
) -> list[Point]:
    if not all(math.isfinite(v) for v in (long_axis, short_axis, angle, straight, radius)):
        raise ValueError("尺寸必须为有限数值")
    if not 1 <= long_axis <= 20000 or not 1 <= short_axis <= 20000:
        raise ValueError("长轴和短轴必须在 1–20000 米之间")
    if kind == "Stadium" and (not 0 <= straight <= 20000 or not 1 <= radius <= 5000):
        raise ValueError("直道/弯道尺寸无效")
    local = LocalENU(center)
    theta = math.radians(angle)
    c, s = math.cos(theta), math.sin(theta)
    xy = []
    if kind == "Rectangle":
        xy = [
            (-long_axis / 2, -short_axis / 2),
            (long_axis / 2, -short_axis / 2),
            (long_axis / 2, short_axis / 2),
            (-long_axis / 2, short_axis / 2),
        ]
    elif kind == "Line":
        xy = [(-long_axis / 2, 0), (long_axis / 2, 0)]
    elif kind in ("Ellipse", "Circle"):
        b = long_axis / 2 if kind == "Circle" else short_axis / 2
        xy = [
            (
                long_axis / 2 * math.cos(2 * math.pi * i / samples),
                b * math.sin(2 * math.pi * i / samples),
            )
            for i in range(samples)
        ]
    elif kind == "Stadium":
        # Parametrize by arc length: two semicircles joined exactly by tangents.
        length = 2 * straight + 2 * math.pi * radius
        for i in range(samples):
            d = i * length / samples
            if d < straight:
                x, y = -straight / 2 + d, -radius
            elif d < straight + math.pi * radius:
                t = (d - straight) / radius - math.pi / 2
                x, y = straight / 2 + radius * math.cos(t), radius * math.sin(t)
            elif d < 2 * straight + math.pi * radius:
                x, y = straight / 2 - (d - straight - math.pi * radius), radius
            else:
                t = (d - 2 * straight - math.pi * radius) / radius + math.pi / 2
                x, y = -straight / 2 + radius * math.cos(t), radius * math.sin(t)
            xy.append((x, y))
    else:
        raise ValueError("未知几何形状")
    return [local.inverse(c * x - s * y, s * x + c * y) for x, y in xy]
