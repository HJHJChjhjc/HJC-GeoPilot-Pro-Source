from __future__ import annotations
import asyncio
import os
import sys
import subprocess
from pathlib import Path
from backend.ios_services import IOSServices


class TunnelService:
    async def start(self) -> None:
        try:
            await IOSServices().tunnels()
            return
        except Exception:
            pass
        if sys.platform != "win32":
            raise OSError(
                "此启动器面向 Windows。其他平台请手动运行 pymobiledevice3 remote tunneld。"
            )
        # Elevate only the tunnel child, not the editor/UI.
        import ctypes

        script = Path(__file__).resolve().parents[1] / "app.py"
        args = ["--tunneld", "--parent-pid", str(os.getpid())]
        if not getattr(sys, "frozen", False):
            args.insert(0, str(script))
        result = await asyncio.to_thread(
            ctypes.windll.shell32.ShellExecuteW,
            None,
            "runas",
            sys.executable,
            subprocess.list2cmdline(args),
            str(script.parent),
            1,
        )
        if result <= 32:
            raise OSError(f"UAC 取消或启动失败：{result}")
        for _ in range(40):
            await asyncio.sleep(0.5)
            try:
                await IOSServices().tunnels()
                return
            except Exception:
                pass
        raise TimeoutError("tunneld 启动超时。请查看日志或在管理员终端手动启动。")


def run_tunneld(parent_pid: int = 0) -> None:
    import threading
    import time
    import psutil

    parent = psutil.Process(parent_pid) if parent_pid else None

    def watch() -> None:
        while parent is not None:
            time.sleep(1)
            if not parent.is_running():
                os._exit(0)

    if parent:
        threading.Thread(target=watch, daemon=True).start()
    from pymobiledevice3.tunneld.server import TunneldRunner

    from pymobiledevice3.remote.common import TunnelProtocol

    TunneldRunner.create(host="127.0.0.1", port=49151, protocol=TunnelProtocol.DEFAULT)
