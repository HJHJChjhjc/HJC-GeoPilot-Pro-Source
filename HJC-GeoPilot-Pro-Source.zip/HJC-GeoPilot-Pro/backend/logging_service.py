from __future__ import annotations
import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from collections import deque
from threading import Lock


class MemoryHandler(logging.Handler):
    def __init__(self) -> None:
        super().__init__()
        self.lines: deque[str] = deque(maxlen=4000)
        self.guard = Lock()

    def emit(self, record: logging.LogRecord) -> None:
        with self.guard:
            self.lines.append(self.format(record))

    def snapshot(self, level: str = "ALL") -> str:
        with self.guard:
            return "\n".join(line for line in self.lines if level == "ALL" or f" {level} " in line)


def setup_logging(root: Path) -> MemoryHandler:
    folder = root / "logs"
    folder.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s — %(message)s")
    memory = MemoryHandler()
    memory.setFormatter(fmt)
    file = RotatingFileHandler(
        folder / "geopilot.log", maxBytes=3_000_000, backupCount=4, encoding="utf-8"
    )
    file.setFormatter(fmt)
    logger = logging.getLogger()
    logger.setLevel(logging.DEBUG)
    logger.addHandler(memory)
    logger.addHandler(file)
    logging.getLogger("pymobiledevice3").setLevel(logging.INFO)
    logging.getLogger("qasync").setLevel(logging.WARNING)
    return memory
