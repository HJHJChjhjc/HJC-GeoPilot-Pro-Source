# HJC GeoPilot Pro

**Developed by Hjc · 由 Hjc 开发**  
软件副标题：HJC Jiangke RUN Tool Pro  
iOS Location & Route Simulation Toolkit

本项目是重新实现的 Python / PySide6 Windows 桌面定位与路线开发测试工具。UI、设备通信、地理算法、运动算法、持久化互相分离，没有复制参考项目代码。

**交付状态：可以安装运行的完整源码项目。已完成 Linux 下的原生 Qt 启动、交互回归及自动测试；Windows EXE 构建、Windows USB 驱动和实体 iPhone/iPad 验收尚未完成。这里没有提供未经验证的 `.exe`，也没有承诺 iOS 27 或任意未来 iOS 版本一定兼容。**

## Windows 快速运行

1. 安装 **Python 3.12 Windows x64 版本（本项目的设备依赖需要此版本的 Windows 预编译组件）**，保留 Python Launcher（`py`）。
2. 把整个文件夹解压到可写目录，例如 `D:\HJC-GeoPilot-Pro`。不要直接在 ZIP 内运行。
3. 双击 `setup.bat`，等待依赖安装完成。此步骤需要联网。
4. 双击 `run.bat`，打开软件。
5. 保持顶部 **Offline preview** 勾选，可以先编辑和测试路线；它不会发送设备指令。
6. 对实体设备测试：安装 Apple Devices / Apple Mobile Device USB Driver，连接并解锁设备，在设备上信任电脑。
7. 进入 **Devices → Refresh → 选择设备 → Connect**。现代设备若需要隧道，点击 **Start tunneld** 并处理 Windows UAC。
8. 如果设备提供开发者模式选项，请在设备的“设置 → 隐私与安全性”中启用它。DVT 还可能需要 Developer Disk Image，见诊断文档。
9. 选择顶部目标设备，取消勾选 **Offline preview** 后再按 START。STOP、断开和正常退出会尝试清除模拟定位。清理失败会显示错误，需重新连接后 Restore GPS。

不是所有 iOS 版本、驱动和开发镜像组合都支持 Apple 的模拟定位服务。程序通过实际服务握手检测能力，查询失败表示 UNKNOWN，不会推断成“不需要开发者模式”。

## 页面与功能

| 页面 | 实现内容 |
|---|---|
| Home | 实时仪表盘、路线缩略视图、START / PAUSE / RESUME / STOP |
| Devices | 自动 USB 发现、名称/型号标识/iOS/UDID、复制、连接/断开/重连、独立设备会话 |
| Map | 原生 Qt 交互底图、地点搜索、鼠标坐标、位置标记拖动、地图点击添点 |
| Track Designer | 场地中心、旋转、长短轴或直道/半径、圈数、整条跑道搬移、距离/时间 |
| Route Editor | 任意折线、开放/闭合、直线/矩形/圆/椭圆、拖点、删点、列表拖动排序、Undo/Redo/Clear/Duplicate/Reverse/Smooth |
| Simulation | 固定速度、配速、分段速度、任意起点/跳转、反向、多圈、Linear / CubicSpline、独立设备状态 |
| Manual Control | W/A/S/D、方向键、精确经纬度、地图点击发送、0.5/1/2/5/10 米或自定义、保存/恢复位置 |
| Presets | 任意数量场地、中心/边界/路线/地图/日期/备注、搜索、名称/日期排序、收藏、复制、重命名、JSON 导入导出 |
| Diagnostics | USB、依赖、tunneld、开发者模式、DVT、LocationSimulation，问题与建议、JSON 报告 |
| Logs | INFO/WARNING/ERROR/DEBUG、实时过滤、复制/导出、轮转日志 |
| Settings | Light/Dark/System、单位、工作区恢复、About 和数据目录 |

多设备不是“同时给全部设备发送同一条路线”。选择设备 A 启动后可以切换设备 B，再设置另一条路线启动；每个运行会话都保存自己的路线副本、引擎、暂停状态和轨迹。全局编辑工作区不会改变已经运行的路线。暂停/继续/停止只作用于当前目标。

## 地图与坐标

- 全部输入、输出和设备指令都是 **WGS84**。不要直接粘贴高德 GCJ-02 或百度 BD-09 坐标。文件明确声明其他坐标系时会拒绝。
- Normal 为 OpenStreetMap；Satellite 为 Esri World Imagery；Route 为 OSM 底图加粗路线显示。
- 搜索通过 Nominatim，按钮触发、限制调用频率，不自动补全轰炸服务。底图按当前视图下载，Qt HTTP 缓存最大 150 MB，不批量预取。
- 在线搜索、普通图和卫星图需要相应服务可达。本次执行环境未验证线上底图和搜索的可达性。网络失败会显示底图提示，网格、经纬度、路线编辑和手动坐标仍能工作，点击 Retry tiles 可重试。
- 绿色标记代表工作区/模拟位置；蓝线是路线；绿线是当前目标走过的轨迹。
- Map 页点击和拖标记只编辑工作区位置。**Manual Control 页**点击/拖动会发送至选中的目标；运行路线时会拒绝手动覆盖。
- 投影：地图显示使用 Web Mercator；测量用 WGS84 `Geod`；形状在 WGS84→ECEF→局部 ENU 中生成，再反变换。
- 示例路线中心只是示例，**不是江西科技学院操场的经核实坐标**。请自行在地图选择真实场地。

## 跑道和模拟语义

标准体育场几何为两条相等直道加两个半圆，几何周长 `2L + 2πR`。界面中的 400 m geometry 按这个公式设置直道长度；生成路径离散化后的测量会有毫米级差异。它没有宣称包含正式比赛测量线、分道/起跑线等全部体育场认证规则。

方向 0° 指长轴朝东，90° 朝北，逆时针为正。长轴=直道+2×半径，短轴=2×半径；两组尺寸不会同时互相矛盾。点击地图/拖动中心搬动整条路线，改角度旋转。

运动根据实际单调时钟与速度推进米制弧长，按设定 1–20 Hz 采样，不是每隔固定时间跳到下一个原始点。设备发送延迟可能降低实际刷新频率，下一次采样使用真实时间增量。它不会伪造加速度传感器或第三方校验。

- 单位：m/s、km/h、min/km。速度保存为 m/s。
- 分段 JSON 示例：`[{"distance_m":0,"speed_ms":2},{"distance_m":100,"speed_ms":3.2}]`。distance_m 必须递增，速度按路线位置线性插值，变化受到加速度限制。
- 配置改动作用于下一次 START。运行中的每台设备保留独立副本。
- 闭合路线可从任意点完成指定圈数；开放路线多次运行会往返，避免跨端点瞬移。
- Reverse 从反向遍历顺序的所选点开始。Start / Jump point 是从 1 开始的索引。
- 跳转是明确的位置重置，不计入已走距离；剩余距离/进度会相应变化。
- PAUSE 不增加运动距离/运动时间；停止/完成后速度显示 0。
- ETA 使用当前目标速度估算，所以标为约数，不是对未来速度变化的保证。
- Spline 在 ENU 中平滑，可能越出控制点包络，必须看地图确认。限 20 km；长路线可使用 geodesic Linear。Spline 运行会重采样，须从第 1 点开始；可先在编辑器 Smooth，再选新的点索引。

## 文件与恢复

JSON 字段包括 `name/version/author/created_at/coordinate_system/points/speed_profile/metadata/closed`，输出 `author` 固定为 `Hjc`。坐标点使用 `{ "lat": 28.68, "lon": 115.98 }`，兼容导入旧 `lng` 字段及参考仓库的 `coordinates`。旧格式没有坐标系时会标记“假定 WGS84”，使用前须确认。

GPX 支持 trkpt/rtept/wpt，XML 使用 defusedxml 安全解析。多段 GPX 会拒绝并要求拆分，避免把轨迹断点连接起来。GPX 只保存名称、作者、坐标与闭合端点，分段速度和其他扩展元数据保存在 JSON。

文件限制：20 MB、100000 点；Spline 最多生成 20000 点。编辑复杂大型路线时建议先简化，以降低列表和绘制开销。边界默认保存路线的包围矩形，可以在导出的预设 JSON 中编辑为任意点列；当前没有独立的边界多边形绘制工具。

提供 `portable.flag` 时数据放在程序旁边的 `data/`；无此标记则放在 `%LOCALAPPDATA%\HJC-GeoPilot-Pro`，可用 `HJC_DATA_DIR` 环境变量覆盖。资源从程序/打包资源目录读取，不依赖运行终端的当前目录。

设置和工作区采用临时文件+原子替换写入；编辑后延迟保存，并每 10 秒检查点保存。配置损坏保留 `settings.invalid.json` 再恢复默认。正常退出保存窗口大小。异常重启恢复路线和最近工作位置，**不自动重新发送 GPS 或自动开始上一次设备任务**。Windows 任务管理器强制结束可能无法清理设备定位，需重新连接 Restore GPS。

## 测试和打包

双击 **build.bat**：安装开发依赖 → 算法/服务测试 → GUI smoke → PyInstaller onedir → 打包后 smoke → Portable ZIP。

成功输出：

```text
dist/HJC-GeoPilot-Pro/HJC-GeoPilot-Pro.exe
dist/HJC-GeoPilot-Pro-Portable.zip
```

必须把整个目录一起分发，不能单独复制 EXE，依赖在 `_internal/`。PyInstaller 不能从本 Linux 环境交叉构建 Windows 程序。打包配置没有硬编码 Python 安装目录，并收集 pymobiledevice3、pytun-pmd3 和依赖；QtNetwork 不会被错误排除。

也提供 `.github/workflows/windows-build.yml`：把项目放入自己的 GitHub 仓库后，手动触发 Windows portable build；本次未替你上传或执行此流水线。打包结果仍需要实体设备验收，自动化测试不是硬件兼容证明。

开发命令：

```powershell
py -3.12 -m venv .venv
.venv\Scripts\python -m pip install -r requirements-dev.txt
.venv\Scripts\python -m pytest -q
.venv\Scripts\python app.py
.venv\Scripts\python tools\gui_check.py
.venv\Scripts\python -m PyInstaller hjc-geopilot.spec --clean --noconfirm
```

新手完整操作步骤见：[中文使用教程](docs/使用教程.md)。更多细节：[诊断说明](docs/DIAGNOSTICS.md)、[Windows 构建与验收](docs/WINDOWS.md)、[参考项目分析](docs/REFERENCE_ANALYSIS.md)、[阶段与验证记录](docs/VALIDATION.md)、[完整目录](docs/STRUCTURE.md)。

## 第三方组件

采用 PySide6、qasync、pymobiledevice3、PROJ/pyproj、NumPy、SciPy 等组件，分别保留其自身许可。字体为 Noto Sans CJK SC（SIL OFL），许可位于 `assets/fonts/OFL.txt`。参考仓库代码没有复制进这个项目。署名显示 **Developed by Hjc / 由 Hjc 开发** 不改变第三方组件的作者或许可。
