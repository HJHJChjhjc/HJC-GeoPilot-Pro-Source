@echo off
setlocal
cd /d "%~dp0"
set "RESULT=1"
where py >nul 2>&1
if errorlevel 1 goto no_python
py -3.12 -c "import sys; assert sys.version_info[:2] == (3,12) and sys.maxsize > 2**32"
if errorlevel 1 goto wrong_python
if exist ".venv\Scripts\python.exe" ".venv\Scripts\python.exe" -c "import sys; assert sys.version_info[:2] == (3,12) and sys.maxsize > 2**32" >nul 2>&1
if errorlevel 1 rmdir /s /q .venv
if not exist ".venv\Scripts\python.exe" py -3.12 -m venv .venv
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" -c "import PySide6, qasync, pyproj, scipy"
if errorlevel 1 goto failed
set "RESULT=0"
echo Setup completed. Start the app with run.bat.
goto finish
:no_python
echo Python Launcher was not found. Install Python 3.12, 64-bit, then retry.
goto finish
:wrong_python
echo Python 3.12, 64-bit is required. Install Python 3.12 and retry.
goto finish
:failed
echo Setup failed. Check the error above and docs\DIAGNOSTICS.md.
:finish
echo.
echo Press any key to close this window.
pause >nul
endlocal & exit /b %RESULT%
