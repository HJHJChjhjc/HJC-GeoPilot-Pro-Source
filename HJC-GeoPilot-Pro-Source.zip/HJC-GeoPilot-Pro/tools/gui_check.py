"""Run native Qt/qasync integration and save preview screenshots. No hardware mocks in UI."""

from __future__ import annotations
import asyncio
import os
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ["HJC_DATA_DIR"] = tempfile.mkdtemp(prefix="hjc-gui-")
from PySide6.QtWidgets import QApplication
from PySide6.QtCore import Qt, QPoint
from PySide6.QtTest import QTest
from PySide6.QtGui import QFontDatabase
from qasync import QEventLoop
from backend.config_manager import ConfigManager
from backend.logging_service import setup_logging
from backend.models import Point
from backend.geometry import distance
from ui.controller import Controller
from ui.main_window import MainWindow
from ui.theme import stylesheet

app = QApplication([])
app.setStyle("Fusion")
QFontDatabase.addApplicationFont(
    str(Path(__file__).resolve().parents[1] / "assets/fonts/NotoSansCJKsc-Regular.otf")
)
app.setStyleSheet(stylesheet("Light"))
loop = QEventLoop(app)
asyncio.set_event_loop(loop)
config = ConfigManager()
config.data["auto_refresh"] = False
c = Controller(config, setup_logging(config.root))
window = MainWindow(c)
window.show()
errors = []
c.error.connect(errors.append)
output = Path(__file__).resolve().parents[1] / "docs" / "screenshots"
output.mkdir(parents=True, exist_ok=True)


async def check():
    try:
        await c.initialize()
        window.nav.setCurrentRow(3)
        track = window.pages[3]
        track.map.configure(Point(28.68, 115.98), 18, "Normal")
        await track.generate()
        track.map.fit()
        await asyncio.sleep(0.2)
        assert len(c.state.route.points) == 720
        center_before = c.state.route.metadata["center"].copy()
        start = track.map.screen(c.state.position).toPoint()
        QTest.mousePress(track.map, Qt.MouseButton.LeftButton, pos=start)
        QTest.mouseMove(track.map, start + QPoint(30, 10))
        QTest.mouseRelease(track.map, Qt.MouseButton.LeftButton, pos=start + QPoint(30, 10))
        await asyncio.sleep(0.2)
        assert c.state.route.metadata["center"] != center_before
        window.grab().save(str(output / "track-designer.png"))
        window.nav.setCurrentRow(4)
        editor = window.pages[4]
        editor.map.fit()
        editor.reverse()
        c.history_action()
        await asyncio.sleep(0.1)
        assert len(c.state.route.points) == 720
        # Click to add a route point, then move/delete it via widget events.
        initial = len(c.state.route.points)
        QTest.mouseClick(editor.map, Qt.MouseButton.LeftButton, pos=QPoint(100, 100))
        assert len(c.state.route.points) == initial + 1
        editor.delete_point(initial)
        assert len(c.state.route.points) == initial
        editor.close_route()
        assert not c.state.route.closed
        editor.close_route()
        assert c.state.route.closed
        window.grab().save(str(output / "route-editor.png"))
        window.nav.setCurrentRow(5)
        simulation = window.pages[5]
        await simulation.start()
        await asyncio.sleep(0.35)
        c.simulation.pause("preview")
        paused = c.simulation.runs["preview"].engine.completed
        await asyncio.sleep(0.25)
        assert c.simulation.runs["preview"].engine.completed == paused
        c.simulation.resume("preview")
        await asyncio.sleep(0.2)
        assert c.simulation.runs["preview"].engine.completed > paused
        window.grab().save(str(output / "dashboard.png"))
        await c.simulation.stop("preview")
        window.nav.setCurrentRow(6)
        manual = window.pages[6]
        p = c.state.position
        await asyncio.gather(c.manual_delta(1, 0), c.manual_delta(1, 0))
        assert 1.99 < distance(p, c.state.position) < 2.01
        manual.save_position()
        await c.manual_delta(1, 0)
        await c.manual(c.state.saved_position)
        window.nav.setCurrentRow(7)
        presets = window.pages[7]
        await presets.create("GUI 测试场地")
        assert len(presets.items) == 1
        presets.list.setCurrentRow(0)
        presets.load()
        path = config.root / "routes" / "gui-route.json"
        await c.export_route(path)
        await c.save_workspace()
        assert path.exists()
        window.nav.setCurrentRow(8)
        await window.pages[8].run()
        window.nav.setCurrentRow(10)
        window.pages[10].theme.setCurrentText("Dark")
        window.nav.setCurrentRow(0)
        await asyncio.sleep(0.15)
        window.grab().save(str(output / "home-dark.png"))
        assert not errors, errors
        # Verify shutdown called from a tracked task does not cancel/gather itself.
        await c.shutdown()
        print(
            "GUI integration PASS: 11 pages, map editing, track, run/pause/resume/stop, manual, presets, IO, diagnostics, theme, shutdown"
        )
        print("Screenshots:", output)
    finally:
        window.allow_close = True
        window.close()


with loop:
    loop.run_until_complete(check())
