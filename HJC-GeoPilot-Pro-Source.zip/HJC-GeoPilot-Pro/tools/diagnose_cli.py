"""Hardware diagnostics available even when a GUI cannot start."""

import asyncio
import sys
from pathlib import Path
from dataclasses import asdict

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from backend.diagnostics import diagnose
from backend.device_manager import DeviceManager
from backend.config_manager import ConfigManager, atomic_json


async def main() -> None:
    manager = DeviceManager()
    try:
        checks = await diagnose(manager)
        for c in checks:
            print(f"{c.component}: {c.status}\n  {c.problem}\n  {c.advice}\n")
        path = ConfigManager().root / "diagnostics.json"
        atomic_json(path, [asdict(c) for c in checks])
        print(path)
    finally:
        await manager.close()


if __name__ == "__main__":
    asyncio.run(main())
