@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    call setup.bat
    if errorlevel 1 goto finish
)
".venv\Scripts\python.exe" tools\diagnose_cli.py
echo.
echo Press any key to close this window.
pause >nul
endlocal
