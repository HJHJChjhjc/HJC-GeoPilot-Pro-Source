# -*- mode: python ; coding: utf-8 -*-
"""Windows x64 onedir build. Developed by Hjc. No machine-specific paths."""
import sys
from pathlib import Path
from PyInstaller.utils.hooks import collect_all,collect_data_files,collect_submodules

if sys.platform != 'win32':
    raise SystemExit('Build this spec on Windows x64; PyInstaller cannot cross-build Windows executables.')
base=Path(SPECPATH)
pm_data,pm_bins,pm_hidden=collect_all('pymobiledevice3')
tun_data,tun_bins,tun_hidden=collect_all('pytun_pmd3')
datas=pm_data+tun_data+[(str(base/name),name) for name in ('assets','configs','routes')]
datas += [(str(base/'README.md'),'.'),(str(base/'docs/DIAGNOSTICS.md'),'docs')]
a=Analysis([str(base/'app.py')],pathex=[str(base)],binaries=pm_bins+tun_bins,datas=datas,
    hiddenimports=pm_hidden+tun_hidden+['qasync','PySide6.QtNetwork','PySide6.QtSvg'],
    hookspath=[],runtime_hooks=[],excludes=['PyQt5','PyQt6','tkinter','PySide6.QtWebEngineCore','PySide6.QtWebEngineWidgets','PySide6.QtMultimedia'],noarchive=False)
pyz=PYZ(a.pure)
exe=EXE(pyz,a.scripts,[],exclude_binaries=True,name='HJC-GeoPilot-Pro',debug=False,bootloader_ignore_signals=False,
    strip=False,upx=False,console=False,disable_windowed_traceback=False,
    icon=str(base/'assets/app.ico') if (base/'assets/app.ico').exists() else None,
    version=str(base/'installer/version.txt'))
coll=COLLECT(exe,a.binaries,a.datas,strip=False,upx=False,name='HJC-GeoPilot-Pro')
