from dataclasses import dataclass


@dataclass(frozen=True)
class TileProvider:
    url: str
    attribution: str


PROVIDERS = {
    "Normal": TileProvider(
        "https://tile.openstreetmap.org/{z}/{x}/{y}.png", "© OpenStreetMap contributors"
    ),
    "Satellite": TileProvider(
        "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
        "Tiles © Esri · Maxar · Earthstar Geographics",
    ),
    "Route": TileProvider(
        "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
        "© OpenStreetMap contributors · Route overlay",
    ),
}
