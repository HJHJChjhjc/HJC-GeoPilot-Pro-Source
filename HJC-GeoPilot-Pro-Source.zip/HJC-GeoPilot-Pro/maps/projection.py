"""Web Mercator is for display only. Measurements use WGS84 geodesics."""

import math
from backend.models import Point


def world(point: Point, zoom: int) -> tuple[float, float]:
    scale = 256 * 2**zoom
    lat = math.radians(max(-85.05112878, min(85.05112878, point.lat)))
    return (point.lon + 180) / 360 * scale, (1 - math.asinh(math.tan(lat)) / math.pi) / 2 * scale


def geographic(x: float, y: float, zoom: int) -> Point:
    scale = 256 * 2**zoom
    return Point(
        math.degrees(math.atan(math.sinh(math.pi * (1 - 2 * max(0, min(scale, y)) / scale)))),
        (x / scale * 360) % 360 - 180,
    )
