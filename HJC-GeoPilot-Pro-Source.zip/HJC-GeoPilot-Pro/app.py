"""HJC GeoPilot Pro — Developed by Hjc / 由 Hjc 开发."""

from __future__ import annotations
import argparse
import asyncio
import os
import sys

# Windowed PyInstaller processes may not have streams; tunneld's logging needs them.
for stream in ("stdout", "stderr"):
    if getattr(sys, stream) is None:
        setattr(sys, stream, open(os.devnull, "w", encoding="utf-8"))


def main() -> None:
    parser = argparse.ArgumentParser(description="HJC GeoPilot Pro — Developed by Hjc")
    parser.add_argument("--tunneld", action="store_true")
    parser.add_argument("--parent-pid", type=int, default=0)
    parser.add_argument(
        "--smoke-test",
        action="store_true",
        help="Construct all pages, paint, and exit; no hardware claim",
    )
    args = parser.parse_args()
    from backend.config_manager import ConfigManager
    from backend.logging_service import setup_logging

    config = ConfigManager()
    memory = setup_logging(config.root)
    if args.tunneld:
        from backend.tunnel_service import run_tunneld

        run_tunneld(args.parent_pid)
        return
    from PySide6.QtWidgets import QApplication
    from PySide6.QtGui import QFont, QFontDatabase, QIcon
    from qasync import QEventLoop
    from ui.controller import Controller
    from ui.main_window import MainWindow
    from ui.theme import stylesheet

    app = QApplication(sys.argv)
    app.setApplicationName("HJC GeoPilot Pro")
    app.setOrganizationName("Hjc")
    app.setStyle("Fusion")
    app.setFont(QFont("Segoe UI", 10))
    from backend.config_manager import RESOURCE_ROOT

    QFontDatabase.addApplicationFont(
        str(RESOURCE_ROOT / "assets" / "fonts" / "NotoSansCJKsc-Regular.otf")
    )
    app.setStyleSheet(stylesheet(config.data["theme"]))
    app.styleHints().colorSchemeChanged.connect(
        lambda _: app.setStyleSheet(stylesheet(config.data["theme"]))
    )
    loop = QEventLoop(app)
    asyncio.set_event_loop(loop)
    import logging

    def exception_handler(loop, context):
        logging.getLogger(__name__).error(
            "Async exception: %s",
            context.get("message"),
            exc_info=context.get("exception"),
        )
        c.error.emit(str(context.get("exception", context.get("message"))))

    loop.set_exception_handler(exception_handler)

    def excepthook(kind, value, tb):
        logging.getLogger(__name__).error("Unhandled exception", exc_info=(kind, value, tb))
        c.error.emit(f"{kind.__name__}: {value}")

    sys.excepthook = excepthook
    c = Controller(config, memory)
    window = MainWindow(c)
    window.setWindowIcon(QIcon(str(RESOURCE_ROOT / "assets/app.svg")))
    window.show()

    async def startup():
        if args.smoke_test:
            for i in range(len(window.pages)):
                window.navigate(i)
                await asyncio.sleep(0.03)
            await c.shutdown()
            window.allow_close = True
            window.close()
        else:
            await c.initialize()

    exit_code = 0

    def startup_done(task):
        nonlocal exit_code
        if task.cancelled():
            return
        error = task.exception()
        if error:
            logging.getLogger(__name__).error("Startup failed", exc_info=error)
            exit_code = 1
            app.exit(1)

    with loop:
        task = loop.create_task(startup())
        task.add_done_callback(startup_done)
        loop.run_forever()
    logging.getLogger(__name__).info("Application exit")
    if exit_code:
        raise SystemExit(exit_code)


if __name__ == "__main__":
    main()
