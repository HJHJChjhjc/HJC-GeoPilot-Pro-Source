@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" call setup.bat
if errorlevel 1 goto finish
".venv\Scripts\python.exe" -c "import PySide6, qasync, pyproj, scipy" >nul 2>&1
if errorlevel 1 call setup.bat
if errorlevel 1 goto finish
".venv\Scripts\python.exe" -c "import PySide6, qasync, pyproj, scipy" >nul 2>&1
if errorlevel 1 goto missing_dependencies
".venv\Scripts\python.exe" app.py
if errorlevel 1 (
    echo.
    echo The application returned an error.
    echo See data\logs\geopilot.log for details.
)
goto finish
:missing_dependencies
echo Required packages are still missing. Check the setup error above.
:finish
echo.
echo Press any key to close this window.
pause >nul
endlocal
