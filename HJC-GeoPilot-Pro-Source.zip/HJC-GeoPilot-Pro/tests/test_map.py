import pytest
from backend.models import Point
from maps.projection import world, geographic


@pytest.mark.parametrize("lat,lon", [(0, 0), (28.68, 115.98), (-60, -170), (80, 179.99)])
@pytest.mark.parametrize("zoom", [2, 10, 18])
def test_mercator_roundtrip(lat, lon, zoom):
    original = Point(lat, lon)
    x, y = world(original, zoom)
    p = geographic(x, y, zoom)
    assert p.lat == pytest.approx(lat, abs=1e-8)
    assert p.lon == pytest.approx(lon, abs=1e-8)
