import pytest
from backend.geometry import offset, distance
from backend.models import Point, Route
from backend.movement_engine import MovementEngine


def route(closed=False):
    p = Point(28, 115)
    return Route(points=[p, offset(p, 10, 0), offset(p, 20, 0)], closed=closed)


def test_fixed_speed_pause_seek_stop():
    e = MovementEngine(route(), 2)
    e.resume()
    t = e.step(2)
    assert t.distance_m == pytest.approx(4)
    e.pause()
    t = e.step(100)
    assert t.elapsed_s == 2 and t.distance_m == 4
    e.seek(1)
    assert e.snapshot().distance_m == 4
    e.resume()
    t = e.step(1)
    assert t.distance_m == 6
    e.stop()
    assert e.step(5).status == "Stopped"


def test_open_pingpong_no_teleport():
    e = MovementEngine(route(), 2, 2)
    e.resume()
    previous = e.snapshot().point
    for _ in range(220):
        t = e.step(0.1)
        assert distance(previous, t.point) <= 0.201
        previous = t.point
    assert t.status == "Completed"
    assert t.distance_m == pytest.approx(40, abs=0.01)
    assert distance(t.point, route().points[0]) < 0.01


def test_reverse_open():
    r = route()
    e = MovementEngine(r, 2, reverse=True)
    e.resume()
    assert distance(e.snapshot().point, r.points[-1]) < 0.01
    for _ in range(110):
        t = e.step(0.1)
    assert t.status == "Completed"
    assert distance(t.point, r.points[0]) < 0.01


def test_closed_arbitrary_start_complete_lap():
    e = MovementEngine(route(True), 2, 3, start_index=1)
    e.resume()
    for _ in range(700):
        t = e.step(0.1)
    assert t.status == "Completed"
    assert t.distance_m == pytest.approx(e.path.length * 3, abs=0.01)
    assert distance(t.point, route().points[1]) < 0.01
    assert t.lap == 3


def test_profile_acceleration():
    r = route()
    r.speed_profile = [
        {"distance_m": 0, "speed_ms": 2},
        {"distance_m": 10, "speed_ms": 5},
    ]
    e = MovementEngine(r, 2)
    e.resume()
    speeds = []
    for _ in range(20):
        speeds.append(e.step(0.1).speed_ms)
    assert all(abs(a - b) <= 0.151 for a, b in zip(speeds, speeds[1:]))
    assert speeds[-1] > speeds[0]


def test_duplicate_points_supported():
    r = route()
    r.points.insert(1, r.points[0])
    e = MovementEngine(r)
    assert e.path.length > 19
    e.seek(1)
    assert e.path.point_distance(1) == 0
