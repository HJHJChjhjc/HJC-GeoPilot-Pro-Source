import json
import pytest
from backend.models import Point, Route, Preset
from backend.route_manager import RouteManager
from backend.preset_manager import PresetManager
from backend.config_manager import ConfigManager


@pytest.mark.parametrize("suffix", [".json", ".gpx"])
def test_roundtrip(tmp_path, suffix):
    r = Route(
        name="中文跑道",
        points=[Point(28, 115), Point(28.001, 115.001), Point(28.002, 115.001)],
        closed=True,
    )
    m = RouteManager()
    p = tmp_path / f"test{suffix}"
    m.save(p, r)
    loaded = m.load(p)
    assert loaded.name == r.name and loaded.points == r.points and loaded.closed
    if suffix == ".json":
        assert json.loads(p.read_text())["author"] == "Hjc"
    else:
        assert b'creator="Hjc"' in p.read_bytes()


def test_config_recover(tmp_path):
    c = ConfigManager(tmp_path)
    c.data["theme"] = "Dark"
    c.save()
    assert ConfigManager(tmp_path).data["theme"] == "Dark"
    (tmp_path / "settings.json").write_text("{bad")
    recovered = ConfigManager(tmp_path)
    assert recovered.warning
    assert (tmp_path / "settings.invalid.json").exists()


def test_reject_invalid_coordinates_and_profile():
    with pytest.raises(ValueError):
        Point(float("nan"), 0)
    with pytest.raises(ValueError):
        Route.parse({"coordinate_system": "GCJ02"})
    with pytest.raises(ValueError):
        Route(speed_profile=[{"distance_m": 1, "speed_ms": -2}]).validate()


def test_preset_unlimited_and_unique_safe_names(tmp_path):
    m = PresetManager(tmp_path)
    p = Preset("../../中文", Point(0, 0), Route())
    a = m.save(p)
    b = m.save(p)
    assert a != b and a.parent == tmp_path
    assert len(m.list()) == 2
    assert m.load(a).name == p.name


def test_gpx_reject_entity_and_disconnected_segments(tmp_path):
    path = tmp_path / "x.gpx"
    path.write_text('<!DOCTYPE gpx [<!ENTITY x SYSTEM "file:///etc/passwd">]><gpx>&x;</gpx>')
    with pytest.raises(Exception):
        RouteManager().load(path)
    path.write_text(
        '<gpx><trk><trkseg><trkpt lat="0" lon="0"/></trkseg><trkseg><trkpt lat="1" lon="1"/></trkseg></trk></gpx>'
    )
    with pytest.raises(ValueError):
        RouteManager().load(path)
