import asyncio
import pytest
from backend.device_manager import DeviceManager
from backend.models import DeviceInfo, Point, Route
from backend.location_service import LocationService
from backend.simulation_service import SimulationService
from backend.geometry import offset


class Provider:
    def __init__(self):
        self.closed = False

    async def close(self):
        self.closed = True


class Location:
    def __init__(self):
        self.points = []
        self.cleared = False
        self.closed = False

    async def set(self, p):
        self.points.append(p)

    async def clear(self):
        self.cleared = True

    async def close(self):
        self.closed = True
        self.cleared = True


class Adapter:
    def __init__(self):
        self.locations = []
        self.providers = []

    async def lockdown(self, u):
        p = Provider()
        self.providers.append(p)
        return p

    async def remote(self, u):
        p = Provider()
        self.providers.append(p)
        return p

    async def location(self, p):
        # Exercise capability fallback with a real adapter contract, no hardware claims.
        if len(self.providers) == 1:
            raise ConnectionError("direct DVT unavailable")
        loc = Location()
        self.locations.append(loc)
        return loc


@pytest.mark.asyncio
async def test_capability_fallback_and_cleanup():
    a = Adapter()
    m = DeviceManager(a)
    m.devices["u"] = DeviceInfo("u")
    s = await m.connect("u")
    assert s.info.connection == "Connected (Tunnel)"
    assert a.providers[0].closed
    await m.disconnect("u")
    assert s.provider.closed and s.location.cleared


@pytest.mark.asyncio
async def test_independent_device_simulation_pause_and_clear():
    m = DeviceManager(Adapter())
    m.devices = {"a": DeviceInfo("a"), "b": DeviceInfo("b")}
    await m.connect("a")
    await m.connect("b")
    service = SimulationService(LocationService(m), lambda k, t: None, lambda k, e: None)
    p = Point(28, 115)
    r = Route(points=[p, offset(p, 20, 0)])
    await service.start("a", r, 2, 1, 0, False, 20)
    await service.start("b", r, 4, 1, 0, False, 20)
    await asyncio.sleep(0.2)
    service.pause("a")
    d = service.runs["a"].engine.completed
    await asyncio.sleep(0.2)
    assert service.runs["a"].engine.completed == d
    assert service.runs["b"].engine.completed > d
    await service.close()
    assert all(s.location.cleared for s in m.sessions.values())
    await m.close()


@pytest.mark.asyncio
async def test_double_start_serialized():
    m = DeviceManager(Adapter())
    service = SimulationService(LocationService(m), lambda k, t: None, lambda k, e: None)
    p = Point(28, 115)
    r = Route(points=[p, offset(p, 20, 0)])
    await asyncio.gather(
        service.start("preview", r, 2, 1, 0, False, 20),
        service.start("preview", r, 3, 1, 0, False, 20),
    )
    await asyncio.sleep(0.02)
    running = [
        t
        for t in asyncio.all_tasks()
        if not t.done() and "SimulationService._loop" in str(t.get_coro())
    ]
    assert len(running) == 1
    await service.close()
