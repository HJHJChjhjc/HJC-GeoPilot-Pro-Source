import math
import pytest
from backend.models import Point, Route
from backend.geometry import LocalENU, shape, distance, interpolate, transform
from backend.route_engine import RoutePath, smooth, RouteHistory


@pytest.mark.parametrize("lat,lon", [(0, 0), (28.68, 115.98), (75, 20), (-70, 179.99)])
def test_enu_roundtrip(lat, lon):
    center = Point(lat, lon)
    enu = LocalENU(center)
    for x, y in [(1, 0), (0, 1), (70, -120), (1000, 2000)]:
        p = enu.inverse(x, y)
        east, north, _ = enu.forward(p)
        assert abs(east - x) < 0.002
        assert abs(north - y) < 0.002


@pytest.mark.parametrize("angle", [0, 45, 90, 178])
def test_track_meter_length(angle):
    route = Route(
        points=shape(Point(28.68, 115.98), "Stadium", 160, 74, angle, 84.39, 36.8, 720),
        closed=True,
    )
    path = RoutePath(route)
    assert abs(path.length - (2 * 84.39 + 2 * math.pi * 36.8)) < 0.01
    assert len(route.points) == 720


def test_dateline_interpolation():
    a, b = Point(0, 179.999), Point(0, -179.999)
    mid = interpolate(a, b, 0.5)
    assert abs(abs(mid.lon) - 180) < 1e-8
    assert 200 < distance(a, b) < 230


def test_spline_closed_and_degenerate():
    r = Route(points=shape(Point(60, 10), "Rectangle", 100, 60), closed=True)
    s = smooth(r)
    assert s.closed and len(s.points) > 200
    assert distance(s.points[0], s.points[-1]) < 3
    with pytest.raises(ValueError):
        RoutePath(Route(points=[Point(0, 0), Point(0, 0)]))


def test_history_independent():
    a = Route(points=[Point(0, 0), Point(0, 0.001)])
    h = RouteHistory(a)
    b = Route(points=[Point(1, 1), Point(2, 2)])
    h.commit(b)
    b.points.clear()
    assert len(h.current.points) == 2
    assert h.undo().points == a.points
    assert h.redo().points[0] == Point(1, 1)


def test_transform_translation_rotation():
    origin = Point(0, 0)
    dest = Point(60, 30)
    p = LocalENU(origin).inverse(10, 0)
    translated = transform([p], origin, dest, 90)[0]
    x, y, _ = LocalENU(dest).forward(translated)
    assert abs(x) < 0.001 and abs(y - 10) < 0.001
