# Windows 安装、打包和设备验收

Developed by Hjc · 由 Hjc 开发

## 本机源码运行

目标 Windows 10/11 x64，Python 3.12 x64。解压到可写目录，依次双击 setup.bat 和 run.bat。安装 Python 时应安装 Launcher；执行 `py -3.12 --version` 检查。本项目当前固定使用 Python 3.12 x64：pymobiledevice3 的 lzfse/pylzss 在其他版本可能没有 Windows 预编译 wheel，pip 会报缺少 Visual C++ Build Tools。依赖安装失败时不要继续打包，先解决网络或 Python wheel 错误。

首次可以保留 Offline preview，不接设备就测试全部几何/路线编辑。地图/搜索仍需网络。例子在 routes/example-track.json 和 routes/example-track.gpx。

设备前置：Apple USB 驱动、解锁、信任、设备所需的开发者模式/Developer Disk Image。只有 tunneld 子进程需要请求 UAC，编辑器不会默认以管理员运行。程序探测服务能力，不硬编码某个 iOS 版本就声明兼容。

## 打包

双击 build.bat。脚本会在每次失败时停下，不会生成“成功”的假提示。onedir 模式输出 `HJC-GeoPilot-Pro.exe` 和 `_internal`，随后生成 Portable ZIP。`portable.flag` 在 EXE 旁时数据写在旁边的 data，整个目录可以搬动。

打包脚本不是 Windows 安装器。用户明确要求的 Portable 已提供构建方式；未制作 MSI 或自动安装 Apple 驱动。安装 Apple 驱动应使用 Apple 官方渠道。便携版首次不需要安装 Python，但仍需要硬件驱动和服务条件。

打包后至少做两次测试：

1. 开发电脑：运行 EXE、翻页、导入示例、生成跑道、保存后重开；管理员隧道启动。
2. 干净 Windows x64：不装 Python，完整解压 Portable ZIP，重复离线操作和实体设备测试。保留日志、版本、设备型号与系统版本。

压缩包不能只含 EXE。Qt 平台插件、Python、科学计算库、iOS 服务库、wintun、字体和 `_internal` 均可能参与运行。

## 实体 iPhone/iPad 验收表（尚未执行）

| 验收项目 | 操作 | 通过条件 |
|---|---|---|
| USB 发现 | 连接解锁/锁定/拔插两台设备 | 显示真实名称、型号标识、版本、UDID，错误可理解 |
| 开发者能力 | 开/关开发者模式或不支持查询 | Enabled / Disabled / Unknown 与实际对应 |
| DVT 通道 | Connect 与 Reconnect | 真实通道打开，失败理由和降级路径可见 |
| 手动定位 | 用自己的 CoreLocation 测试 App 读点 | 经纬度与发送值相符 |
| 路线采样 | 运行 400 m 示例/自建路线 | 连续移动，速度/配速/点位正确 |
| 独立设备 | A 运行，B 运行另一条路线 | 暂停 A 不影响 B，目标切换数据正确 |
| 清理 | Stop、Disconnect、退出 | 尝试恢复 GPS，失败不会被隐藏 |
| 异常断线 | 运行时拔 USB | 停止该设备任务，报错可追溯，UI 继续工作 |
| 暂停/跳转 | 暂停 30 秒，再继续和跳点 | 暂停不加距离/时间；跳转不计作已走路程 |
| UI/DPI | 100%、150%、200% Windows 缩放 | 控件不遮挡，滚动可到达，中文无缺字 |
| Portable | 干净电脑无 Python | EXE 可运行，依赖完整，数据持久化 |

用设备能力而非营销版本推断可用性。验证某台设备后，记录它的具体 iOS build、库版本、驱动状态；不能推广为“所有较新 iOS 已验证”。

## 可选 GitHub Windows 构建

项目附带 Windows GitHub Actions，手动触发后生成可下载的构建 artifact。需要用户自己的仓库与账户；本会话没有发布、推送或触发外部流水线。云端 Windows smoke 可以检查打包，但不能代替你的 USB/iPhone 验收。
