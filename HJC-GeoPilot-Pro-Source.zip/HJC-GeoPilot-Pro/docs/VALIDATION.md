# 阶段记录与验证边界

Developed by Hjc · 由 Hjc 开发

这是实际工作的记录，不把“已写代码”当作“实体设备通过”。阶段按用户顺序推进；早期尚无完整 UI 时使用对应模块/组件运行，完整窗口在 Phase 9 组装。未满足每个早期阶段都运行完整最终程序的字面要求，最终组装后重复了完整窗口启动与交互回归。

| 阶段 | 实现/检查 | 状态 |
|---|---|---|
| Phase 1 | 读取参考仓库、源码 API 与实际安装包接口；保存提交标识 | 已执行 |
| Phase 2 | 模型、配置、状态、模块目录、compileall | 已执行 |
| Phase 3 | 真实 USB/DVT/LocationSimulation 适配器，USB discovery 实际调用 | 代码/接口检查完成；本环境 PermissionError，无设备通过记录 |
| Phase 4 | 原生 Qt MapWidget 构造与离屏绘制、投影转换 | 已执行；线上底图/搜索网络未验收 |
| Phase 5 | WGS84/ECEF/ENU、Geod 距离、RoutePath、CubicSpline | 算法运行/测试通过 |
| Phase 6 | 720 点体育场、中心搬移/旋转/尺寸、界面截图 | 几何与 GUI 回归通过 |
| Phase 7 | 距离推进、速度配置、pause/resume/stop/seek、开放往返 | 算法与离线 GUI 通过 |
| Phase 8 | JSON/GPX、原子持久化、恢复、预设管理 | 文件/GUI 测试通过 |
| Phase 9 | 全部 11 页面、双主题、署名、中文字体 | 整程序 smoke/交互回归通过 |
| Phase 10 | Diagnostics、原生 CLI、日志与错误提示 | 当前环境诊断已运行；硬件相关保持 NOT TESTED/UNKNOWN |
| Phase 11 | Windows + iPhone | **未执行：没有目标 Windows 环境和 USB iPhone/iPad** |
| Phase 12 | 修复事件循环启动、任务自取消、地图 180° 错位、字体、反向起点、目标切换、拖移等 | 已修复并回归 |
| Phase 13 | PyInstaller spec、Windows build/run/setup、Portable ZIP 与 CI | 构建资料完成；**Windows EXE 尚未生成或验收** |

本次验证环境：Linux x64，Python 3.12，PySide6 6.11.2，qasync 0.28.0，pymobiledevice3 11.21.0，pyproj 3.8.0，SciPy 1.17.0。目标支持 Python 3.11+，Python 3.11 的 Windows 测试须在提供的流程中完成。

自动化覆盖：ENU 高低纬度往返、跑道长度/旋转、日期变更线插值、Mercator 往返、Spline、零长线段、Undo/Redo 副本、移动速度、暂停、跳转、反向、开放往返、多圈、速度变化、JSON/GPX 中文往返、异常配置恢复、坐标系拒绝、XML 实体拒绝、多段 GPX 拒绝、预设唯一文件、模拟适配器降级/关闭、两台设备独立任务与停止清理。

`test_services.py` 的设备适配器是明确的单元测试替身，不参与生产代码，也不作为真实设备证据。生产 UI 中没有假 iPhone 或假服务成功状态。

Qt 集成检查：原生 MainWindow/qasync、11 页面、真实地图事件添点、删点、闭合切换、Track Designer、Offline preview start/pause/resume/stop、两个快速手动步进、位置保存/恢复、预设、路线导出、Diagnostics、Dark 主题和退出。

截图保存在 docs/screenshots，仅展示此环境的实际绘制结果，未用合成卫星图伪装在线加载成功。

2026-10-04 Windows 用户截图显示旧 ZIP 中的 `.bat` 文件使用 LF 换行且含无 BOM UTF-8 中文，Windows `cmd.exe` 将命令拆坏并以“不是内部或外部命令”结束。已将所有批处理改为纯 ASCII + CRLF，并让 run.bat/setup.bat 始终停留以显示错误。请使用更新后的 ZIP。

已修复的关键缺陷：

- Qt 构造时还没有 running loop，改成在已设定的 qasync loop 上排队任务。
- shutdown 从受管理任务调用时不能取消/等待自己，排除 current_task。
- Web Mercator inverse 经度偏移 180°，新增多纬度、多缩放回归。
- Linux 缺 CJK 字体，提供带许可的 Noto 字体。
- 快速手动步进串行计算，避免多个任务读同一个旧位置。
- 反向开放路线正确从反向序列点开始，重复运行往返。
- 原始点重叠先移除零长线段，防止插值除零。
- 目标切换清空旧设备轨迹，不在完成后持续覆盖手动位置。
- 库的同步 tunneld HTTP 改成 async HTTP；大路线引擎构建转工作线程。

运行最终命令后的详细摘要位于 `test-results.txt`。Windows 清单见 WINDOWS.md，任何未执行项都不能视为通过。
