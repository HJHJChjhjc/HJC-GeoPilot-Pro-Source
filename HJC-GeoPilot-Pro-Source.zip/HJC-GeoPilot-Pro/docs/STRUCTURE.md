# 完整目录与文件

Developed by Hjc · 由 Hjc 开发

| 文件 | 内容 |
|---|---|
| `.github/workflows/windows-build.yml` | Windows 构建流水线 |
| `README.md` | 使用说明 |
| `app.py` | GUI / tunneld 入口 |
| `assets/app.ico` | 图标、字体及许可 |
| `assets/app.svg` | 图标、字体及许可 |
| `assets/fonts/NotoSansCJKsc-Regular.otf` | 图标、字体及许可 |
| `assets/fonts/OFL.txt` | 图标、字体及许可 |
| `backend/__init__.py` | 独立业务 / 设备 / GIS / 运动 / 配置模块 |
| `backend/config_manager.py` | 独立业务 / 设备 / GIS / 运动 / 配置模块 |
| `backend/device_manager.py` | 独立业务 / 设备 / GIS / 运动 / 配置模块 |
| `backend/diagnostics.py` | 独立业务 / 设备 / GIS / 运动 / 配置模块 |
| `backend/geometry.py` | 独立业务 / 设备 / GIS / 运动 / 配置模块 |
| `backend/ios_services.py` | 独立业务 / 设备 / GIS / 运动 / 配置模块 |
| `backend/location_service.py` | 独立业务 / 设备 / GIS / 运动 / 配置模块 |
| `backend/logging_service.py` | 独立业务 / 设备 / GIS / 运动 / 配置模块 |
| `backend/models.py` | 独立业务 / 设备 / GIS / 运动 / 配置模块 |
| `backend/movement_engine.py` | 独立业务 / 设备 / GIS / 运动 / 配置模块 |
| `backend/preset_manager.py` | 独立业务 / 设备 / GIS / 运动 / 配置模块 |
| `backend/route_engine.py` | 独立业务 / 设备 / GIS / 运动 / 配置模块 |
| `backend/route_manager.py` | 独立业务 / 设备 / GIS / 运动 / 配置模块 |
| `backend/simulation_service.py` | 独立业务 / 设备 / GIS / 运动 / 配置模块 |
| `backend/tunnel_service.py` | 独立业务 / 设备 / GIS / 运动 / 配置模块 |
| `build.bat` | Windows 测试、EXE 和 Portable 构建 |
| `configs/default.json` | 默认配置 |
| `diagnose.bat` | 开发配置 |
| `docs/DIAGNOSTICS.md` | 说明 / 验证 / 实际截图 |
| `docs/REFERENCE_ANALYSIS.md` | 说明 / 验证 / 实际截图 |
| `docs/VALIDATION.md` | 说明 / 验证 / 实际截图 |
| `docs/WINDOWS.md` | 说明 / 验证 / 实际截图 |
| `docs/screenshots/dashboard.png` | 说明 / 验证 / 实际截图 |
| `docs/screenshots/home-dark.png` | 说明 / 验证 / 实际截图 |
| `docs/screenshots/route-editor.png` | 说明 / 验证 / 实际截图 |
| `docs/screenshots/track-designer.png` | 说明 / 验证 / 实际截图 |
| `docs/test-results.txt` | 说明 / 验证 / 实际截图 |
| `hjc-geopilot.spec` | Windows PyInstaller 配置 |
| `installer/version.txt` | Windows 版本元数据 |
| `logs/README.txt` | 日志目录说明 |
| `maps/__init__.py` | 显示投影与底图 |
| `maps/projection.py` | 显示投影与底图 |
| `maps/providers.py` | 显示投影与底图 |
| `portable.flag` | 开发配置 |
| `pyproject.toml` | 开发配置 |
| `pytest.ini` | 开发配置 |
| `requirements-dev.txt` | 测试 / 打包依赖 |
| `requirements.txt` | 运行依赖 |
| `routes/example-track.gpx` | 示例路线 |
| `routes/example-track.json` | 示例路线 |
| `run.bat` | Windows 运行 |
| `setup.bat` | Windows 首次依赖安装 |
| `tests/test_files.py` | 自动测试 |
| `tests/test_geometry.py` | 自动测试 |
| `tests/test_map.py` | 自动测试 |
| `tests/test_movement.py` | 自动测试 |
| `tests/test_services.py` | 自动测试 |
| `tools/diagnose_cli.py` | GUI 回归 / CLI 诊断 |
| `tools/gui_check.py` | GUI 回归 / CLI 诊断 |
| `ui/__init__.py` | Qt 页面、状态、控制器、组件 |
| `ui/controller.py` | Qt 页面、状态、控制器、组件 |
| `ui/dialogs/__init__.py` | Qt 页面、状态、控制器、组件 |
| `ui/dialogs/about.py` | Qt 页面、状态、控制器、组件 |
| `ui/main_window.py` | Qt 页面、状态、控制器、组件 |
| `ui/pages/__init__.py` | Qt 页面、状态、控制器、组件 |
| `ui/pages/devices_page.py` | Qt 页面、状态、控制器、组件 |
| `ui/pages/diagnostics_page.py` | Qt 页面、状态、控制器、组件 |
| `ui/pages/logs_page.py` | Qt 页面、状态、控制器、组件 |
| `ui/pages/manual_page.py` | Qt 页面、状态、控制器、组件 |
| `ui/pages/map_page.py` | Qt 页面、状态、控制器、组件 |
| `ui/pages/presets_page.py` | Qt 页面、状态、控制器、组件 |
| `ui/pages/route_editor_page.py` | Qt 页面、状态、控制器、组件 |
| `ui/pages/settings_page.py` | Qt 页面、状态、控制器、组件 |
| `ui/pages/simulation_page.py` | Qt 页面、状态、控制器、组件 |
| `ui/pages/track_page.py` | Qt 页面、状态、控制器、组件 |
| `ui/state.py` | Qt 页面、状态、控制器、组件 |
| `ui/theme.py` | Qt 页面、状态、控制器、组件 |
| `ui/widgets/__init__.py` | Qt 页面、状态、控制器、组件 |
| `ui/widgets/common.py` | Qt 页面、状态、控制器、组件 |
| `ui/widgets/map_widget.py` | Qt 页面、状态、控制器、组件 |
| `docs/使用教程.md` | 中文使用教程 |
| `docs/STRUCTURE.md` | 本目录清单 |
| `docs/SHA256SUMS.txt` | 打包源文件校验清单 |

- docs/使用教程.md：Windows 安装、离线预览、路线/跑道、模拟、设备连接与故障排查的中文用户教程。
