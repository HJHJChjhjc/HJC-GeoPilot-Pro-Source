# Phase 1：参考仓库分析

参考：https://github.com/andynubia12-byte/College-Running-Assistant-Only-For-iPhone  
读取时提交：`579a57aa9edc47f8eaff5ea35e9e17646573fc87`。

读取范围包括 README、DEVPLAN、requirements、app.py，backend、configs、routes、ui（页面/控制器/主题/字体目录信息）、installer，以及 main.py、构建/运行脚本、GPX 导入、隧道入口和 spec。字体二进制不是 Python 源码，未使用参考项目字体。源码通过 git 获得；网页检索在本会话中不可用。

| 原实现 | 本项目决策 |
|---|---|
| app.py 通过 qasync 桥接 Qt 和 asyncio，--tunneld 启动独立服务 | 保留这种合理模式，单独 `tunnel_service`，只提升隧道子进程 |
| backend/device.py 仅从 get_tunneld_devices 得到设备 | USB 独立发现，实际探测 USB DVT，再降级/切换到隧道 RSD |
| ui/app_state.py 全局单例，rsd_list/localizers 为全局批量状态 | 显式 Controller，设备会话字典，运动会话字典，每个会话保存独立路线副本 |
| 开发者模式查询异常直接返回 None，并假定是旧系统不支持 | UNKNOWN 保留错误原因，不按版本号伪造结论 |
| backend/modes.py 用 111320 m/deg 和 cos(lat) 近似计算，四角取包围矩形 | PROJ 的 WGS84/ECEF 转换与局部 ENU，形状与 geodesic 距离分离 |
| 跑道每圈随机缩放、随机 jitter | 确定性几何与速度轨迹，不实现规避反作弊的随机化 |
| gen_route 依据固定点间隔发点，点密度影响速度 | 按米制弧长 + 真实 dt 推进，任意原始点密度均能插值 |
| Route 页面仅列表加载；Calibrate 页面逐角手动标定 | 原生 Qt 底图、任意路线控制点、顺序编辑和 Track Designer |
| JSON 保存 coordinates / route_name，GPX 转换只提坐标 | 版本化 JSON 元数据、速度配置、坐标系验证、JSON/GPX 双向读写 |
| 配置采用相对 cwd 路径和非原子覆盖 | pathlib、资源/可写数据分离、原子替换、异常恢复与检查点 |
| run_controller cancel 后清理，但全局运行状态和批量 localizers 耦合 | 每台设备一个任务；清理失败显示错误；退出等待任务和设备关闭 |
| geosim.spec 硬编码某台电脑的 wintun.dll 路径，排除 QtNetwork | collect_all/pytun-pmd3 获取真实包资源，保留 QtNetwork |
| home_page 部分连接失败分支使用未定义 count | 新代码对连接结果与异常统一通知，回归测试独立失败与清理 |

DEVPLAN 是计划文档，部分说明与实际代码/依赖不一致，例如计划中说不需要 uvicorn，但实际 tunneld 仍依赖其服务。因此新实现以实际源码与安装包 API 为依据，不机械照抄计划。

API 依据：官方 pymobiledevice3 源码仓库 https://github.com/doronz88/pymobiledevice3 ，读取时主分支提交 `db31bf8d5c72d4483f1a4331fd27da82bcbe87ef`；实际安装并核查的版本为 **11.21.0**（requirements 固定）。USB list_devices/create_using_usbmux 与 LocationSimulation.set/clear 均为异步接口。新项目实际导入并运行了 USB 检测；本环境无 USB 权限，错误被捕获，没有伪造设备。

`tunneld.api.get_tunneld_devices` 的异步函数内部存在同步 requests GET。新适配器用 httpx 异步读取同一 HTTP 响应，按返回的地址与端口构造 RemoteServiceDiscoveryService，再异步连接和关闭，避免同步 HTTP 阻塞 GUI。
