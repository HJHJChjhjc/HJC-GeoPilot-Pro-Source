# 错误诊断

Developed by Hjc · 由 Hjc 开发

在程序内打开 Diagnostics → 一键诊断。无法打开 GUI 时，先运行 setup.bat，再运行 diagnose.bat。诊断不会强行启用开发者模式，也不会要求关闭锁屏密码。

| 现象 | 可能原因 | 处理 |
|---|---|---|
| `No module named ...` | 依赖未安装或用了另一个 Python | setup.bat；始终使用 .venv\Scripts\python.exe |
| USB 无设备 | Apple 驱动/服务、线缆、信任状态 | 安装 Apple Devices；设备管理器检查 Apple USB；用数据线并解锁信任 |
| PermissionError | 运行环境无设备访问权、USB 服务权限 | 在真正连接设备的 Windows 电脑运行；检查驱动、服务和权限 |
| 配对失败 / Locked / untrusted | 锁定、信任未确认、过期配对 | 解锁手机；确认信任；先用 Apple Devices 检查能否识别 |
| Developer Mode UNKNOWN | 查询服务不可用或握手失败 | 不等于关闭/无需开启；查看错误，人工检查设备设置 |
| Developer Mode Disabled | 开发者模式关闭 | 如设备提供此项，在设置中手动启用并按设备提示重启 |
| tunneld 未启动 | 服务尚未运行、UAC 拒绝、端口占用 | Devices → Start tunneld；或管理员终端手动启动 |
| tunneld 有服务但零隧道 | 驱动、设备未信任、开发者服务、DDI | 检查连接、设备解锁、开发者模式、开发镜像 |
| InvalidService / DVT 不可用 | 服务不支持、DDI 未挂载、系统变化 | 检查开发镜像；查询对应版本 upstream issue；离线编辑仍可用 |
| DVT PASS 但设备地图没变化 | 通道可打开，但 App 未使用该服务、缓存、兼容问题 | 用自己的 CoreLocation 测试 App 检查，记录结果；PASS 不保证所有 App 生效 |
| 地图空白 | 底图不可达、网络/代理、证书 | 等待加载；Retry tiles；精确坐标/网格仍可编辑，检查服务可达性 |
| 地点搜索失败 | Nominatim 网络/限流 | 每次搜索间隔至少 1.1 秒；也可直接输入 latitude, longitude |
| 路线与卫星图错位 | 把 GCJ-02/BD-09 当 WGS84、示例位置错误 | 确认坐标系；重新选择中心，不用未经核实的校园示例 |
| Restore GPS 失败 | USB 丢失或 DVT 断开 | 停止任务，重新连接，再 Restore GPS；必要时重启设备 |
| PyInstaller 找不到 DLL/模块 | 构建不在正确环境、依赖不同 | 使用 Windows x64 venv 和 build.bat；保留 warn-HJC-GeoPilot-Pro.txt |
| EXE 无响应/打不开 | 未完整解压、杀毒拦截、打包依赖缺失 | 保留整个 onedir；检查数据日志；回退源码运行排查 |

源码模式下，在项目目录打开管理员终端：

```powershell
.venv\Scripts\python.exe -m pymobiledevice3 remote tunneld
```

若 DVT 报 Developer Disk Image 相关错误，可查看已核查的 CLI：

```powershell
.venv\Scripts\python.exe -m pymobiledevice3 mounter auto-mount --help
.venv\Scripts\python.exe -m pymobiledevice3 mounter auto-mount
```

该操作可能下载 Apple 开发镜像并与设备通信，实际能否挂载由设备服务和库支持决定。本软件没有把下载/挂载结果伪装成“已支持所有 iOS”。多台设备时，先看命令帮助选择明确的目标。

日志含技术错误和可能的设备信息，导出前可查看内容。日志是 data/logs/geopilot.log，每个约 3 MB，最多保留 4 个备份。GUI 保留最近 4000 行。
