from __future__ import annotations
from ui.controller import Controller
from PySide6.QtWidgets import (
    QLabel,
    QComboBox,
    QApplication,
    QLineEdit,
    QAbstractSpinBox,
)
from PySide6.QtGui import QShortcut, QKeySequence
from backend.models import Point
from ui.widgets.common import row, button, spin
from ui.pages.map_page import MapPanel


class ManualPage(MapPanel):
    def __init__(self, c: Controller) -> None:
        super().__init__(
            c,
            "Manual Control",
            "手动定位 · 点击地图或用 W/A/S/D、方向键移动 · 发送至顶部选中的目标",
        )
        self.lat = spin(c.state.position.lat, -90, 90, decimals=8)
        self.lon = spin(c.state.position.lon, -180, 180, decimals=8)
        self.steps = QComboBox()
        self.steps.addItems(["0.5", "1", "2", "5", "10", "Custom"])
        self.steps.setCurrentText("1")
        self.step = spin(1, 0.01, 10000, " m", 2)
        self.step.setEnabled(False)
        self.steps.currentTextChanged.connect(self.set_step)
        self.layout.insertLayout(
            3,
            row(
                QLabel("Latitude"),
                self.lat,
                QLabel("Longitude"),
                self.lon,
                button(
                    "SET LOCATION",
                    lambda: c.launch(c.manual(Point(self.lat.value(), self.lon.value()))),
                    True,
                ),
            ),
        )
        self.layout.insertLayout(
            4,
            row(
                QLabel("Step"),
                self.steps,
                self.step,
                button("↑ W", lambda: self.move(0, 1)),
                button("← A", lambda: self.move(-1, 0)),
                button("↓ S", lambda: self.move(0, -1)),
                button("→ D", lambda: self.move(1, 0)),
            ),
        )
        self.layout.insertLayout(
            5,
            row(
                button("Save position", self.save_position),
                button("Restore saved", self.restore_position),
                button(
                    "Restore GPS",
                    lambda: c.launch(c.location.clear(c.state.selected_device)),
                ),
            ),
        )
        self.map.clicked.connect(lambda point: c.launch(c.manual(point)))
        self.map.edit_position = True
        self.map.position_moved.connect(lambda point: c.launch(c.manual(point)))
        self.shortcuts = []
        for keys, x, y in [
            ("W", 0, 1),
            ("Up", 0, 1),
            ("A", -1, 0),
            ("Left", -1, 0),
            ("S", 0, -1),
            ("Down", 0, -1),
            ("D", 1, 0),
            ("Right", 1, 0),
        ]:
            shortcut = QShortcut(QKeySequence(keys), self)
            shortcut.activated.connect(lambda x=x, y=y: self.keyboard_move(x, y))
            self.shortcuts.append(shortcut)
        c.position_changed.connect(self.update_inputs)
        saved = c.config.data.get("saved_position")
        if saved:
            try:
                c.state.saved_position = Point.parse(saved)
            except ValueError:
                pass

    def set_step(self, text: str) -> None:
        self.step.setEnabled(text == "Custom")
        if text != "Custom":
            self.step.setValue(float(text))

    def keyboard_move(self, x: int, y: int) -> None:
        if not self.isVisible():
            return
        focus = QApplication.focusWidget()
        if isinstance(focus, (QLineEdit, QAbstractSpinBox)):
            return
        self.move(x, y)

    def move(self, x: int, y: int) -> None:
        self.c.launch(self.c.manual_delta(x * self.step.value(), y * self.step.value()))

    def update_inputs(self, point: Point) -> None:
        if not self.lat.hasFocus():
            self.lat.setValue(point.lat)
        if not self.lon.hasFocus():
            self.lon.setValue(point.lon)

    def save_position(self) -> None:
        self.c.state.saved_position = self.c.state.position
        self.c.schedule_save()
        self.c.message.emit("当前位置已保存")

    def restore_position(self) -> None:
        if self.c.state.saved_position:
            self.c.launch(self.c.manual(self.c.state.saved_position))
        else:
            self.c.message.emit("尚未保存位置")
