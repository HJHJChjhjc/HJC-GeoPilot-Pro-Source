from __future__ import annotations
import asyncio
from ui.controller import Controller
import copy
import json
from PySide6.QtWidgets import (
    QGridLayout,
    QLabel,
    QProgressBar,
    QSpinBox,
    QCheckBox,
    QComboBox,
    QPlainTextEdit,
)
from backend.route_engine import smooth
from ui.pages.map_page import MapPanel
from ui.widgets.common import card, button, row, spin


class SimulationPage(MapPanel):
    def __init__(self, c: Controller, home: bool = False) -> None:
        super().__init__(
            c,
            "Control Center" if home else "Route Simulation",
            "按设备独立运行 · Offline preview 可离线测试路线 · STOP 会尝试恢复真实 GPS",
        )
        self.map.editable = False
        self.speed = spin(c.config.data["speed_ms"], 0.1, 100, decimals=2)
        self.units = QComboBox()
        self.units.addItems(["m/s", "km/h", "min/km"])
        self.units.setCurrentText(c.config.data["speed_unit"])
        self.previous_unit = "m/s"
        self.units.currentTextChanged.connect(self.change_unit)
        self.change_unit(self.units.currentText())
        self.loops = QSpinBox()
        self.loops.setRange(1, 10000)
        self.loops.setValue(1)
        self.index = QSpinBox()
        self.index.setRange(1, 100000)
        self.reverse = QCheckBox("Reverse")
        self.interpolation = QComboBox()
        self.interpolation.addItems(["Linear", "Spline"])
        self.hz = spin(c.config.data["refresh_hz"], 1, 20, " Hz", 0)
        self.layout.insertLayout(
            3,
            row(
                QLabel("Speed / Pace"),
                self.speed,
                self.units,
                QLabel("Laps"),
                self.loops,
                QLabel("Start / Jump point"),
                self.index,
                self.reverse,
                self.interpolation,
                self.hz,
            ),
        )
        self.layout.insertLayout(
            4,
            row(
                button("START", lambda: c.launch(self.start()), True),
                button("PAUSE", lambda: c.simulation.pause(c.key)),
                button("RESUME", lambda: c.simulation.resume(c.key)),
                button("STOP", lambda: c.launch(c.simulation.stop(c.key))),
                button("Jump to point", self.seek),
                button("Follow position", self.follow),
            ),
        )
        frame, layout = card()
        grid = QGridLayout()
        self.values = {}
        for i, name in enumerate(
            [
                "Latitude",
                "Longitude",
                "Speed",
                "Pace",
                "Distance",
                "Remaining",
                "Elapsed Time",
                "ETA",
                "Point / Lap",
                "State",
            ]
        ):
            box = QLabel(name)
            box.setObjectName("subtitle")
            value = QLabel("—")
            value.setObjectName("metric")
            grid.addWidget(box, (i // 5) * 2, i % 5)
            grid.addWidget(value, (i // 5) * 2 + 1, i % 5)
            self.values[name] = value
        layout.addLayout(grid)
        self.progress = QProgressBar()
        self.progress.setRange(0, 1000)
        layout.addWidget(self.progress)
        self.layout.insertWidget(5, frame)
        self.profile = QPlainTextEdit()
        self.profile.setPlaceholderText(
            '[{"distance_m":0,"speed_ms":2.0},{"distance_m":100,"speed_ms":3.2}]'
        )
        self.profile.setMaximumHeight(65)
        if not home:
            self.layout.addLayout(
                row(
                    QLabel("分段速度 JSON（按米线性过渡）"),
                    button("Apply speed profile", self.apply_profile),
                )
            )
            self.layout.addWidget(self.profile)
        c.telemetry_changed.connect(self.update_telemetry)
        c.route_changed.connect(self.route_changed)
        self.route_changed(c.state.route)

    def route_changed(self, route) -> None:
        self.index.setMaximum(max(1, len(route.points)))
        self.loops.setValue(int(route.metadata.get("laps", self.loops.value())))
        self.profile.setPlainText(json.dumps(route.speed_profile, ensure_ascii=False))

    def change_unit(self, unit: str) -> None:
        value = self.speed.value()
        ms = (
            value / 3.6
            if self.previous_unit == "km/h"
            else 1000 / (60 * value)
            if self.previous_unit == "min/km"
            else value
        )
        new = ms * 3.6 if unit == "km/h" else 1000 / (60 * ms) if unit == "min/km" else ms
        self.speed.setRange(0.01, 360 if unit == "km/h" else 200 if unit == "min/km" else 100)
        self.speed.setValue(new)
        self.previous_unit = unit

    def speed_ms(self) -> float:
        value = self.speed.value()
        unit = self.units.currentText()
        return value / 3.6 if unit == "km/h" else 1000 / (60 * value) if unit == "min/km" else value

    async def start(self) -> None:
        speed = self.speed_ms()
        route = copy.deepcopy(self.c.state.route)
        if self.interpolation.currentText() == "Spline":
            route = await asyncio.to_thread(smooth, route)
            # Point index must remain defined after resampling.
            if self.index.value() != 1:
                raise ValueError("Spline 重采样请从第 1 点开始；可先在编辑器 Smooth 再选择任意点")
        self.c.config.data.update(
            speed_ms=speed,
            speed_unit=self.units.currentText(),
            refresh_hz=self.hz.value(),
        )
        self.c.schedule_save()
        await self.c.simulation.start(
            self.c.key,
            route,
            speed,
            self.loops.value(),
            self.index.value() - 1,
            self.reverse.isChecked(),
            self.hz.value(),
        )

    def seek(self) -> None:
        try:
            self.c.simulation.seek(self.c.key, self.index.value() - 1)
        except Exception as e:
            self.c.error.emit(str(e))

    def apply_profile(self) -> None:
        try:
            profile = json.loads(self.profile.toPlainText())
            if not isinstance(profile, list):
                raise ValueError("速度配置必须是数组")
            route = copy.deepcopy(self.c.state.route)
            route.speed_profile = profile
            route.validate()
            self.c.commit(route)
        except Exception as e:
            self.c.error.emit(str(e))

    def follow(self) -> None:
        self.map.configure(self.c.state.position, self.map.zoom, self.map.map_type)

    def update_telemetry(self, key: str, t) -> None:
        if key != self.c.key:
            return
        pace = 1000 / (60 * t.speed_ms) if t.speed_ms > 0 else None
        data = {
            "Latitude": f"{t.point.lat:.6f}",
            "Longitude": f"{t.point.lon:.6f}",
            "Speed": f"{t.speed_ms:.2f} m/s",
            "Pace": f"{pace:.2f} min/km" if pace else "—",
            "Distance": f"{t.distance_m:.1f} m",
            "Remaining": f"{t.remaining_m:.1f} m",
            "Elapsed Time": f"{t.elapsed_s:.1f} s",
            "ETA": f"≈ {t.eta_s:.0f} s",
            "Point / Lap": f"{t.point_index + 1} / {t.lap}",
            "State": t.status,
        }
        for name, value in data.items():
            self.values[name].setText(value)
        self.progress.setValue(int(t.progress * 1000))
        run = self.c.simulation.runs.get(key)
        if run:
            self.map.trail = run.trail.copy()
            self.map.update()
