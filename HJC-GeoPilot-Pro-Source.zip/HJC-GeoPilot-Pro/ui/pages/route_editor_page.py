from __future__ import annotations
import asyncio
from ui.controller import Controller
import copy
from pathlib import Path
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QLineEdit,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QFileDialog,
    QInputDialog,
    QComboBox,
    QSplitter,
    QWidget,
    QVBoxLayout,
    QAbstractItemView,
)
from backend.models import Point, Route
from backend.geometry import shape
from backend.route_engine import RoutePath, smooth
from ui.pages.map_page import MapPanel
from ui.widgets.common import button, row, spin


class RouteEditorPage(MapPanel):
    def __init__(self, c: Controller) -> None:
        super().__init__(
            c,
            "Route Editor",
            "地图点击添点 · 拖点移动 · 右键删点 · 列表拖动排序 · 所有修改自动保存",
        )
        self.map.editable = True
        self.map.clicked.connect(self.add_point)
        self.map.point_moved.connect(self.move_point)
        self.map.point_deleted.connect(self.delete_point)
        self.name = QLineEdit(c.state.route.name)
        self.name.editingFinished.connect(self.rename)
        self.stats = QLabel("0 points · 0 m")
        self.layout.insertLayout(3, row(self.name, self.stats))
        self.layout.insertLayout(
            4,
            row(
                button("Undo", lambda: c.history_action()),
                button("Redo", lambda: c.history_action(True)),
                button("Clear", lambda: c.commit(Route(name=self.name.text()))),
                button("Duplicate", self.duplicate),
                button("Reverse", self.reverse),
                button("Smooth", lambda: c.launch(self.smooth())),
                button("Open / Close", self.close_route),
            ),
        )
        self.layout.insertLayout(
            5,
            row(
                button("Import JSON / GPX", self.import_route),
                button("Save / Save as", self.export_route),
                button("Rename", self.rename_dialog),
                button("Delete selected", lambda: self.delete_point(self.list.currentRow())),
                button("↑", lambda: self.reorder(-1)),
                button("↓", lambda: self.reorder(1)),
            ),
        )
        panel = QWidget()
        panel_layout = QVBoxLayout(panel)
        panel.setMaximumWidth(280)
        self.list = QListWidget()
        self.list.setDragDropMode(QAbstractItemView.DragDropMode.InternalMove)
        self.list.model().rowsMoved.connect(lambda *args: QTimer.singleShot(0, self.list_reordered))
        panel_layout.addWidget(QLabel("Route points (拖动排序)"))
        panel_layout.addWidget(self.list, 1)
        self.shape_kind = QComboBox()
        self.shape_kind.addItems(["Line", "Rectangle", "Circle", "Ellipse"])
        self.long = spin(100, 1, 20000, " m")
        self.short = spin(60, 1, 20000, " m")
        self.angle = spin(0, -360, 360, "°")
        panel_layout.addWidget(QLabel("几何形状 · 以绿色位置标记为中心"))
        panel_layout.addWidget(self.shape_kind)
        panel_layout.addWidget(QLabel("长轴 / 直径"))
        panel_layout.addWidget(self.long)
        panel_layout.addWidget(QLabel("短轴"))
        panel_layout.addWidget(self.short)
        panel_layout.addWidget(QLabel("旋转：东向 0°，逆时针"))
        panel_layout.addWidget(self.angle)
        panel_layout.addWidget(button("Generate shape", lambda: c.launch(self.generate()), True))
        self.layout.removeWidget(self.map)
        split = QSplitter()
        split.addWidget(self.map)
        split.addWidget(panel)
        self.layout.insertWidget(6, split, 1)
        c.route_changed.connect(self.update_route)
        self.update_route(c.state.route)

    def update_route(self, route: Route) -> None:
        self.name.setText(route.name)
        self.list.blockSignals(True)
        self.list.clear()
        for i, p in enumerate(route.points):
            item = QListWidgetItem(f"{i + 1:04d}  {p.lat:.6f}, {p.lon:.6f}")
            item.setData(Qt.ItemDataRole.UserRole, p)
            self.list.addItem(item)
        self.list.blockSignals(False)
        self.c.launch(self.calculate_stats(copy.deepcopy(route)))

    async def calculate_stats(self, route: Route) -> None:
        try:
            length = await asyncio.to_thread(lambda: RoutePath(route).length)
        except ValueError:
            length = 0
        if route.points == self.c.state.route.points:
            self.stats.setText(
                f"{len(route.points)} points · {length:.2f} m · {length / self.c.config.data['speed_ms']:.0f} s · {'Closed' if route.closed else 'Open'}"
            )

    def add_point(self, point: Point) -> None:
        route = copy.deepcopy(self.c.state.route)
        route.points.append(point)
        self.c.commit(route)

    def move_point(self, index: int, point: Point) -> None:
        route = copy.deepcopy(self.c.state.route)
        route.points[index] = point
        self.c.commit(route)

    def delete_point(self, index: int) -> None:
        if 0 <= index < len(self.c.state.route.points):
            route = copy.deepcopy(self.c.state.route)
            route.points.pop(index)
            self.c.commit(route)

    def rename(self) -> None:
        if self.name.text().strip() and self.name.text() != self.c.state.route.name:
            route = copy.deepcopy(self.c.state.route)
            route.name = self.name.text().strip()
            self.c.commit(route)

    def rename_dialog(self) -> None:
        name, ok = QInputDialog.getText(self, "Rename route", "Name:", text=self.c.state.route.name)
        if ok and name.strip():
            self.name.setText(name.strip())
            self.rename()

    def duplicate(self) -> None:
        route = copy.deepcopy(self.c.state.route)
        route.name += " copy"
        self.c.commit(route)
        self.export_route()

    def close_route(self) -> None:
        route = copy.deepcopy(self.c.state.route)
        route.closed = not route.closed
        self.c.commit(route)

    def reverse(self) -> None:
        route = copy.deepcopy(self.c.state.route)
        route.points.reverse()
        if route.speed_profile:
            length = RoutePath(route).length
            route.speed_profile = sorted(
                [
                    {
                        "distance_m": max(0, length - p["distance_m"]),
                        "speed_ms": p["speed_ms"],
                    }
                    for p in route.speed_profile
                ],
                key=lambda p: p["distance_m"],
            )
        self.c.commit(route)

    async def smooth(self) -> None:
        route = await asyncio.to_thread(smooth, copy.deepcopy(self.c.state.route))
        self.c.commit(route)
        self.c.message.emit("Spline 可能越出原路线，请在地图检查后运行。Undo 可以恢复。")

    def reorder(self, delta: int) -> None:
        i = self.list.currentRow()
        j = i + delta
        if 0 <= i < len(self.c.state.route.points) and 0 <= j < len(self.c.state.route.points):
            route = copy.deepcopy(self.c.state.route)
            route.points[i], route.points[j] = route.points[j], route.points[i]
            self.c.commit(route)
            self.list.setCurrentRow(j)

    def list_reordered(self) -> None:
        points = [
            self.list.item(i).data(Qt.ItemDataRole.UserRole) for i in range(self.list.count())
        ]
        if points != self.c.state.route.points:
            route = copy.deepcopy(self.c.state.route)
            route.points = points
            self.c.commit(route)

    async def generate(self) -> None:
        kind = self.shape_kind.currentText()
        center = self.c.state.position
        points = await asyncio.to_thread(
            shape,
            center,
            kind,
            self.long.value(),
            self.short.value(),
            self.angle.value(),
        )
        self.c.commit(
            Route(
                name=f"{kind} route",
                points=points,
                closed=kind != "Line",
                metadata={"shape": kind},
            )
        )
        self.map.fit()

    def import_route(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Import route", "", "Routes (*.json *.gpx)")
        if path:
            self.c.launch(self.c.import_route(Path(path)))

    def export_route(self) -> None:
        self.rename()
        path, filter_ = QFileDialog.getSaveFileName(
            self, "Export route", "route.json", "JSON (*.json);;GPX (*.gpx)"
        )
        if path:
            p = Path(path)
            if not p.suffix:
                p = p.with_suffix(".gpx" if "GPX" in filter_ else ".json")
            self.c.launch(self.c.export_route(p))
