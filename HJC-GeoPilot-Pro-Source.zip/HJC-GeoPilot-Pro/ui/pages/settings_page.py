from ui.controller import Controller
from PySide6.QtWidgets import QFormLayout, QComboBox, QCheckBox, QLabel, QApplication
from ui.widgets.common import Page, card, button, row
from ui.theme import stylesheet
from ui.dialogs.about import show_about


class SettingsPage(Page):
    def __init__(self, c: Controller) -> None:
        super().__init__("Settings", "个性化主题与工作区恢复 · 设置自动持久化")
        self.c = c
        frame, layout = card()
        form = QFormLayout()
        self.theme = QComboBox()
        self.theme.addItems(["System", "Light", "Dark"])
        self.theme.setCurrentText(c.config.data["theme"])
        self.restore = QCheckBox("下次启动恢复路线工作区")
        self.restore.setChecked(c.config.data["restore_workspace"])
        self.unit = QComboBox()
        self.unit.addItems(["m/s", "km/h", "min/km"])
        self.unit.setCurrentText(c.config.data["speed_unit"])
        form.addRow("Theme", self.theme)
        form.addRow("Speed unit", self.unit)
        form.addRow("Recovery", self.restore)
        layout.addLayout(form)
        self.layout.addWidget(frame)
        self.theme.currentTextChanged.connect(self.update_settings)
        self.restore.toggled.connect(self.update_settings)
        self.unit.currentTextChanged.connect(self.update_settings)
        self.layout.addWidget(
            QLabel(
                "HJC GeoPilot Pro\nDeveloped by Hjc\n由 Hjc 开发\niOS Location & Route Simulation Toolkit"
            )
        )
        self.layout.addLayout(
            row(
                button("About", lambda: show_about(self)),
                button(
                    "Copy data directory",
                    lambda: QApplication.clipboard().setText(str(c.config.root)),
                ),
            )
        )
        self.layout.addStretch()

    def update_settings(self, *args) -> None:
        self.c.config.data.update(
            theme=self.theme.currentText(),
            speed_unit=self.unit.currentText(),
            restore_workspace=self.restore.isChecked(),
        )
        QApplication.instance().setStyleSheet(stylesheet(self.theme.currentText()))
        self.c.schedule_save()
