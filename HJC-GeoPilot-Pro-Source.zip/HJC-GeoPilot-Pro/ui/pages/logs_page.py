from ui.controller import Controller
import asyncio
from pathlib import Path
from PySide6.QtWidgets import QPlainTextEdit, QComboBox, QApplication, QFileDialog
from PySide6.QtCore import QTimer
from ui.widgets.common import Page, row, button


class LogsPage(Page):
    def __init__(self, c: Controller) -> None:
        super().__init__(
            "Activity & Logs",
            "轮转 UTF-8 日志 · INFO / WARNING / ERROR / DEBUG · 导出前可检查设备信息",
        )
        self.c = c
        self.filter = QComboBox()
        self.filter.addItems(["ALL", "INFO", "WARNING", "ERROR", "DEBUG"])
        self.text = QPlainTextEdit()
        self.text.setReadOnly(True)
        self.text.document().setMaximumBlockCount(4000)
        self.layout.addLayout(
            row(
                self.filter,
                button(
                    "Copy logs",
                    lambda: QApplication.clipboard().setText(self.text.toPlainText()),
                ),
                button("Export logs", self.export),
            )
        )
        self.layout.addWidget(self.text, 1)
        self.timer = QTimer(self)
        self.timer.setInterval(800)
        self.timer.timeout.connect(self.refresh)
        self.timer.start()
        self.previous = ""

    def refresh(self) -> None:
        if not self.isVisible():
            return
        text = self.c.memory.snapshot(self.filter.currentText())
        if text != self.previous:
            bar = self.text.verticalScrollBar()
            at_end = bar.value() >= bar.maximum() - 5
            pos = bar.value()
            self.text.setPlainText(text)
            bar.setValue(bar.maximum() if at_end else pos)
            self.previous = text

    def export(self) -> None:
        path, _ = QFileDialog.getSaveFileName(self, "Export logs", "geopilot.log", "Logs (*.log)")
        if path:
            self.c.launch(self.save(Path(path), self.c.memory.snapshot(self.filter.currentText())))

    async def save(self, path: Path, text: str) -> None:
        await asyncio.to_thread(path.write_text, text, encoding="utf-8")
