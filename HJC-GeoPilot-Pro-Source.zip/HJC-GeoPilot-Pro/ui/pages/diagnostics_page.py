from ui.controller import Controller
from pathlib import Path
import asyncio
from dataclasses import asdict
from PySide6.QtWidgets import QPlainTextEdit, QFileDialog, QApplication
from backend.diagnostics import diagnose
from backend.config_manager import atomic_json
from ui.widgets.common import Page, button, row


class DiagnosticsPage(Page):
    def __init__(self, c: Controller) -> None:
        super().__init__(
            "Diagnostics",
            "检测结果区分 PASS / FAIL / UNKNOWN / NOT TESTED；不会把缺少硬件当作兼容成功",
        )
        self.c = c
        self.checks = []
        self.text = QPlainTextEdit()
        self.text.setReadOnly(True)
        self.layout.addLayout(
            row(
                button("一键诊断", lambda: c.launch(self.run()), True),
                button(
                    "Copy",
                    lambda: QApplication.clipboard().setText(self.text.toPlainText()),
                ),
                button("Export report", self.export),
            )
        )
        self.layout.addWidget(self.text, 1)

    async def run(self) -> None:
        self.text.setPlainText("检测中…")
        self.checks = await diagnose(self.c.devices)
        self.c.devices_changed.emit()
        self.text.setPlainText(
            "\n\n".join(
                f"{r.component}  [{r.status}]\n问题/结果：{r.problem}\n建议：{r.advice}"
                for r in self.checks
            )
        )

    def export(self) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Export diagnostics", "diagnostics.json", "JSON (*.json)"
        )
        if path:
            self.c.launch(self.save(Path(path)))

    async def save(self, path: Path) -> None:
        await asyncio.to_thread(atomic_json, path, [asdict(c) for c in self.checks])
