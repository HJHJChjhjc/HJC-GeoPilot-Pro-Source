from __future__ import annotations
import time
from ui.controller import Controller
import httpx
from PySide6.QtWidgets import QComboBox, QLineEdit, QLabel, QApplication
from backend.models import Point
from ui.widgets.common import Page, button, row
from ui.widgets.map_widget import MapWidget


class MapPanel(Page):
    def __init__(
        self,
        c: Controller,
        title: str = "Map Studio",
        subtitle: str = "WGS84 · 拖动平移 / 滚轮缩放 / 拖动路线点 / 右键删点",
    ) -> None:
        super().__init__(title, subtitle)
        self.c = c
        self.search = QLineEdit()
        self.search.setPlaceholderText("搜索地点，或输入 latitude, longitude")
        self.results = QComboBox()
        self.results.setMinimumWidth(160)
        self.results.activated.connect(self.select_result)
        self.last_search = 0.0
        self.found = []
        self.kind = QComboBox()
        self.kind.addItems(["Normal", "Satellite", "Route"])
        self.kind.setCurrentText(c.config.data["map_type"])
        self.layout.addLayout(
            row(
                self.search,
                button("Search", lambda: c.launch(self.search_place())),
                self.results,
                self.kind,
            )
        )
        self.map = MapWidget(str(c.config.root / "cache"))
        self.map.configure(
            Point.parse(c.config.data["map_center"]),
            c.config.data["zoom"],
            c.config.data["map_type"],
        )
        self.map.set_route(c.state.route.points, c.state.route.closed)
        self.map.position = c.state.position
        self.layout.addWidget(self.map, 1)
        self.coordinates = QLabel("Latitude / Longitude")
        self.layout.addLayout(
            row(
                self.coordinates,
                button("Copy coordinates", self.copy),
                button("Fit route", self.map.fit),
                button("Retry tiles", self.retry_tiles),
            )
        )
        self.map.hovered.connect(
            lambda p: self.coordinates.setText(f"{p.lat:.8f}, {p.lon:.8f}  · WGS84")
        )
        self.map.view_changed.connect(self.view_changed)
        self.kind.currentTextChanged.connect(
            lambda kind: self.map.configure(self.map.center, self.map.zoom, kind)
        )
        c.route_changed.connect(lambda r: self.map.set_route(r.points, r.closed))
        c.position_changed.connect(self.position_changed)
        self.hover_point = c.state.position
        self.map.hovered.connect(self.hovered)

    def retry_tiles(self) -> None:
        self.map.failed.clear()
        self.map.network_message = ""
        self.map.update()

    def hovered(self, point: Point) -> None:
        self.hover_point = point

    def copy(self) -> None:
        QApplication.clipboard().setText(f"{self.hover_point.lat:.8f}, {self.hover_point.lon:.8f}")

    def position_changed(self, point: Point) -> None:
        self.map.position = point
        self.map.update()

    def view_changed(self, point: Point, zoom: int, kind: str) -> None:
        self.c.config.data.update(
            map_center={"lat": point.lat, "lon": point.lon}, zoom=zoom, map_type=kind
        )
        self.c.schedule_save()

    async def search_place(self) -> None:
        query = self.search.text().strip()
        if not query:
            return
        try:
            values = query.replace("，", ",").split(",")
            if len(values) == 2:
                point = Point(float(values[0]), float(values[1]))
                self.map.configure(point, 17, self.kind.currentText())
                self.c.set_position(point)
                return
        except ValueError:
            pass
        if time.monotonic() - self.last_search < 1.1:
            return
        self.last_search = time.monotonic()
        async with httpx.AsyncClient(
            timeout=12,
            headers={"User-Agent": "HJC-GeoPilot-Pro/1.0 desktop route editor"},
        ) as client:
            response = await client.get(
                "https://nominatim.openstreetmap.org/search",
                params={"q": query, "format": "jsonv2", "limit": 5},
            )
            response.raise_for_status()
            self.found = response.json()
        self.results.clear()
        for result in self.found:
            self.results.addItem(result["display_name"])
        if self.found:
            self.select_result(0)
        else:
            self.c.message.emit("没有搜索结果；可以直接输入经纬度")

    def select_result(self, index: int) -> None:
        if 0 <= index < len(self.found):
            result = self.found[index]
            point = Point(float(result["lat"]), float(result["lon"]))
            self.map.configure(point, 17, self.kind.currentText())
            self.c.set_position(point)


class MapPage(MapPanel):
    def __init__(self, c: Controller) -> None:
        super().__init__(c)
        self.action = QComboBox()
        self.action.addItems(["Set workspace position", "Add route point"])
        self.layout.insertLayout(3, row(QLabel("点击地图："), self.action))
        self.map.clicked.connect(self.clicked)
        self.map.edit_position = True
        self.map.position_moved.connect(c.set_position)

    def clicked(self, point: Point) -> None:
        if self.action.currentIndex() == 0:
            self.c.set_position(point)
        else:
            import copy

            route = copy.deepcopy(self.c.state.route)
            route.points.append(point)
            self.c.commit(route)
