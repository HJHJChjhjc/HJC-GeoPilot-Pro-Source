from __future__ import annotations
import asyncio
from ui.controller import Controller
import copy
from pathlib import Path
from PySide6.QtWidgets import (
    QLineEdit,
    QComboBox,
    QListWidget,
    QFileDialog,
    QInputDialog,
    QPlainTextEdit,
)
from backend.models import Preset, Point
from ui.widgets.common import Page, row, button


class PresetsPage(Page):
    def __init__(self, c: Controller) -> None:
        super().__init__(
            "Places & Presets",
            "无限数量场地 · 收藏 / 复制 / 备注 / JSON 导入导出 · 自动保存 WGS84 和 Hjc 作者信息",
        )
        self.c = c
        self.items = []
        self.search = QLineEdit()
        self.search.setPlaceholderText("搜索名称和备注")
        self.sort = QComboBox()
        self.sort.addItems(["Name", "Date"])
        self.layout.addLayout(
            row(
                self.search,
                self.sort,
                button("Refresh", lambda: c.launch(self.refresh())),
            )
        )
        self.list = QListWidget()
        self.layout.addWidget(self.list, 1)
        self.list.currentRowChanged.connect(self.selection)
        self.search.editingFinished.connect(lambda: c.launch(self.refresh()))
        self.sort.currentTextChanged.connect(lambda: c.launch(self.refresh()))
        self.notes = QPlainTextEdit()
        self.notes.setPlaceholderText("场地备注")
        self.notes.setMaximumHeight(100)
        self.layout.addWidget(self.notes)
        self.layout.addLayout(
            row(
                button("Save current place", self.save),
                button("Load selected", self.load, True),
                button("Favorite", lambda: c.launch(self.favorite())),
                button("Duplicate", lambda: c.launch(self.duplicate())),
                button("Rename", self.rename),
                button("Save notes", lambda: c.launch(self.save_notes())),
            )
        )
        self.layout.addLayout(
            row(
                button("Import", self.import_preset),
                button("Export", self.export_preset),
                button("Delete selected", lambda: c.launch(self.delete())),
            )
        )

    async def refresh(self) -> None:
        self.items = await asyncio.to_thread(
            self.c.presets.list, self.search.text(), self.sort.currentText()
        )
        self.list.clear()
        for _, p in self.items:
            self.list.addItem(
                f"{'★ ' if p.favorite else ''}{p.name} · {p.center.lat:.5f}, {p.center.lon:.5f} · {p.created_at[:10]}"
            )

    def selection(self, index: int) -> None:
        if 0 <= index < len(self.items):
            self.notes.setPlainText(self.items[index][1].notes)

    def selected(self):
        i = self.list.currentRow()
        if not 0 <= i < len(self.items):
            raise ValueError("请选择场地")
        return self.items[i]

    def save(self) -> None:
        name, ok = QInputDialog.getText(self, "Save place", "Name:")
        if ok and name.strip():
            self.c.launch(self.create(name.strip()))

    async def create(self, name: str) -> None:
        route = copy.deepcopy(self.c.state.route)
        # Store an explicit bounding rectangle; it can be edited in exported JSON.
        points = route.points
        boundary = []
        if points:
            lo_lat, hi_lat = min(p.lat for p in points), max(p.lat for p in points)
            lo_lon, hi_lon = min(p.lon for p in points), max(p.lon for p in points)
            boundary = [
                Point(lo_lat, lo_lon),
                Point(lo_lat, hi_lon),
                Point(hi_lat, hi_lon),
                Point(hi_lat, lo_lon),
            ]
        preset = Preset(
            name,
            self.c.state.position,
            route,
            boundary,
            self.c.config.data["zoom"],
            self.c.config.data["map_type"],
            notes=self.notes.toPlainText(),
        )
        path = await asyncio.to_thread(self.c.presets.save, preset)
        self.c.config.recent("recent_presets", str(path))
        self.c.schedule_save()
        await self.refresh()

    def load(self) -> None:
        try:
            path, p = self.selected()
            self.c.set_position(p.center)
            self.c.commit(p.route)
            self.c.config.data.update(
                map_center={"lat": p.center.lat, "lon": p.center.lon},
                zoom=p.zoom,
                map_type=p.map_type,
            )
            self.c.config.recent("recent_presets", str(path))
            self.c.schedule_save()
            self.c.message.emit(f"已加载 {p.name}")
            self.c.preset_loaded.emit(p)
        except Exception as e:
            self.c.error.emit(str(e))

    async def favorite(self) -> None:
        path, p = self.selected()
        p.favorite = not p.favorite
        await asyncio.to_thread(self.c.presets.save, p, path)
        await self.refresh()

    async def duplicate(self) -> None:
        _, p = self.selected()
        p = copy.deepcopy(p)
        p.name += " copy"
        await asyncio.to_thread(self.c.presets.save, p)
        await self.refresh()

    def rename(self) -> None:
        try:
            path, p = self.selected()
            name, ok = QInputDialog.getText(self, "Rename place", "Name:", text=p.name)
            if ok and name.strip():
                self.c.launch(self.do_rename(path, p, name.strip()))
        except Exception as e:
            self.c.error.emit(str(e))

    async def do_rename(self, path, p, name) -> None:
        p.name = name
        await asyncio.to_thread(self.c.presets.save, p, path)
        await self.refresh()

    async def save_notes(self) -> None:
        path, p = self.selected()
        p.notes = self.notes.toPlainText()
        await asyncio.to_thread(self.c.presets.save, p, path)

    async def delete(self) -> None:
        path, _ = self.selected()
        await asyncio.to_thread(path.unlink)
        await self.refresh()

    def import_preset(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, "Import place", "", "JSON (*.json)")
        if path:
            self.c.launch(self.do_import(Path(path)))

    async def do_import(self, path: Path) -> None:
        p = await asyncio.to_thread(self.c.presets.load, path)
        await asyncio.to_thread(self.c.presets.save, p)
        await self.refresh()

    def export_preset(self) -> None:
        try:
            _, p = self.selected()
            path, _ = QFileDialog.getSaveFileName(
                self, "Export place", "place.json", "JSON (*.json)"
            )
            if path:
                self.c.launch(self.do_export(p, Path(path)))
        except Exception as e:
            self.c.error.emit(str(e))

    async def do_export(self, p, path) -> None:
        await asyncio.to_thread(
            self.c.presets.save, p, path if path.suffix else path.with_suffix(".json")
        )
