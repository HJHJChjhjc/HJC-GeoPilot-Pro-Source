from PySide6.QtWidgets import (
    QTableWidget,
    QTableWidgetItem,
    QAbstractItemView,
    QCheckBox,
    QLabel,
    QHeaderView,
    QApplication,
)
from ui.widgets.common import Page, button, row
from ui.controller import Controller


class DevicesPage(Page):
    def __init__(self, c: Controller) -> None:
        super().__init__("Device Center", "USB 发现与独立设备会话 · 服务能力通过实际连接检测")
        self.c = c
        self.auto = QCheckBox("自动刷新")
        self.auto.setChecked(c.config.data["auto_refresh"])
        self.auto.toggled.connect(self.auto_changed)
        self.layout.addLayout(
            row(
                button("Refresh", lambda: c.launch(c.refresh())),
                button("Connect", lambda: c.launch(c.connect()), True),
                button("Disconnect", lambda: c.launch(c.disconnect())),
                button("Reconnect", lambda: c.launch(c.reconnect())),
                button("Start tunneld", lambda: c.launch(c.start_tunnel())),
                self.auto,
            )
        )
        self.table = QTableWidget(0, 8)
        self.table.setHorizontalHeaderLabels(
            [
                "Name",
                "Model",
                "iOS",
                "Developer Mode",
                "USB / Connection",
                "tunneld",
                "LocationSimulation",
                "UDID",
            ]
        )
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.itemSelectionChanged.connect(self.select)
        self.layout.addWidget(self.table, 1)
        self.reason = QLabel("连接前请解锁设备，并在设备上信任电脑。")
        self.reason.setWordWrap(True)
        self.layout.addWidget(self.reason)
        self.layout.addLayout(
            row(
                button("Copy UDID", self.copy_udid),
                button(
                    "Restore GPS",
                    lambda: c.launch(c.location.clear(c.state.selected_device)),
                ),
            )
        )
        c.devices_changed.connect(self.refresh)
        self.ids = []

    def auto_changed(self, value: bool) -> None:
        self.c.config.data["auto_refresh"] = value
        self.c.refresh_timer.start() if value else self.c.refresh_timer.stop()
        self.c.schedule_save()

    def refresh(self) -> None:
        self.table.blockSignals(True)
        self.ids = list(self.c.devices.devices)
        self.table.setRowCount(len(self.ids))
        for i, udid in enumerate(self.ids):
            d = self.c.devices.devices[udid]
            for j, value in enumerate(
                (
                    d.name,
                    d.model,
                    d.ios,
                    d.developer_mode,
                    d.connection,
                    d.tunnel,
                    d.location_service,
                    d.udid,
                )
            ):
                self.table.setItem(i, j, QTableWidgetItem(value))
            if udid == self.c.state.selected_device:
                self.table.selectRow(i)
        self.table.blockSignals(False)
        if not self.ids:
            self.reason.setText(
                self.c.devices.usb_error or "未发现 USB 设备。请连接 iPhone/iPad 并解锁。"
            )

    def select(self) -> None:
        i = self.table.currentRow()
        if 0 <= i < len(self.ids):
            self.c.state.selected_device = self.ids[i]
            d = self.c.devices.devices[self.ids[i]]
            self.reason.setText(d.reason or f"{d.name}: {d.connection}")
            self.c.devices_changed.emit()

    def copy_udid(self) -> None:
        QApplication.clipboard().setText(self.c.state.selected_device)
