from __future__ import annotations
import asyncio
from ui.controller import Controller
import math
from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QFormLayout,
    QComboBox,
    QLabel,
    QSplitter,
    QSpinBox,
)
from PySide6.QtCore import QTimer
from backend.models import Point, Route
from backend.geometry import shape
from backend.route_engine import RoutePath
from ui.pages.map_page import MapPanel
from ui.widgets.common import button, spin


class TrackPage(MapPanel):
    def __init__(self, c: Controller) -> None:
        super().__init__(
            c,
            "Track Designer",
            "两段直道 + 两个半圆 · ENU 米制建模 · 点击地图或拖动绿色标记搬动整条跑道",
        )
        self.center = c.state.position
        self.build_id = 0
        panel = QWidget()
        panel.setMaximumWidth(320)
        layout = QVBoxLayout(panel)
        form = QFormLayout()
        self.mode = QComboBox()
        self.mode.addItems(["Straight + Radius", "Long axis + Short axis"])
        self.lat = spin(self.center.lat, -85, 85, decimals=8)
        self.lon = spin(self.center.lon, -180, 180, decimals=8)
        self.straight = spin(84.39, 0, 20000, " m")
        self.radius = spin(36.8, 1, 5000, " m")
        self.long = spin(157.99, 2, 20000, " m")
        self.short = spin(73.6, 2, 10000, " m")
        self.angle = spin(0, -360, 360, "°")
        self.loops = QSpinBox()
        self.loops.setRange(1, 10000)
        self.loops.setValue(1)
        for name, widget in [
            ("Dimensions", self.mode),
            ("Latitude", self.lat),
            ("Longitude", self.lon),
            ("Straight length", self.straight),
            ("Curve radius", self.radius),
            ("Long axis", self.long),
            ("Short axis", self.short),
            ("Rotation (E=0°)", self.angle),
            ("Laps", self.loops),
        ]:
            form.addRow(name, widget)
        layout.addLayout(form)
        self.stats = QLabel()
        self.stats.setWordWrap(True)
        layout.addWidget(self.stats)
        layout.addWidget(button("Generate / Apply", lambda: c.launch(self.generate()), True))
        layout.addWidget(button("400 m geometry", self.standard))
        layout.addStretch()
        self.layout.removeWidget(self.map)
        split = QSplitter()
        split.addWidget(self.map)
        split.addWidget(panel)
        self.layout.insertWidget(3, split, 1)
        self.map.edit_position = True
        self.map.clicked.connect(self.move_center)
        self.map.position_moved.connect(self.move_center)
        self.timer = QTimer(self)
        self.timer.setSingleShot(True)
        self.timer.setInterval(250)
        self.timer.timeout.connect(lambda: c.launch(self.generate()))
        for widget in (
            self.lat,
            self.lon,
            self.straight,
            self.radius,
            self.long,
            self.short,
            self.angle,
            self.loops,
        ):
            widget.valueChanged.connect(self.preview_dimensions)
        self.mode.currentIndexChanged.connect(self.preview_dimensions)
        self.preview_dimensions()

    def preview_dimensions(self, *args) -> None:
        lr = self.mode.currentIndex() == 0
        self.straight.setEnabled(lr)
        self.radius.setEnabled(lr)
        self.long.setEnabled(not lr)
        self.short.setEnabled(not lr)
        radius = self.radius.value() if lr else self.short.value() / 2
        straight = self.straight.value() if lr else self.long.value() - 2 * radius
        if straight < 0:
            self.stats.setText("长轴必须不小于短轴")
            return
        pairs = (
            ((self.long, straight + 2 * radius), (self.short, 2 * radius))
            if lr
            else ((self.straight, straight), (self.radius, radius))
        )
        for widget, value in pairs:
            widget.blockSignals(True)
            widget.setValue(value)
            widget.blockSignals(False)
        length = 2 * straight + 2 * math.pi * radius
        self.stats.setText(
            f"单圈几何长度 {length:.3f} m\n总距离 {length * self.loops.value():.2f} m\n预计 {length * self.loops.value() / self.c.config.data['speed_ms']:.1f} s\n长轴 {straight + 2 * radius:.2f} m · 短轴 {2 * radius:.2f} m"
        )
        if self.isVisible():
            self.timer.start()

    def move_center(self, point: Point) -> None:
        self.lat.blockSignals(True)
        self.lon.blockSignals(True)
        self.lat.setValue(point.lat)
        self.lon.setValue(point.lon)
        self.lat.blockSignals(False)
        self.lon.blockSignals(False)
        self.c.set_position(point)
        self.c.launch(self.generate())

    def standard(self) -> None:
        self.mode.setCurrentIndex(0)
        self.radius.setValue(36.8)
        self.straight.setValue((400 - 2 * math.pi * 36.8) / 2)
        self.c.launch(self.generate())

    async def generate(self) -> None:
        self.build_id += 1
        build = self.build_id
        center = Point(self.lat.value(), self.lon.value())
        radius = self.radius.value()
        straight = self.straight.value()
        if self.mode.currentIndex() == 1:
            radius = self.short.value() / 2
            straight = self.long.value() - 2 * radius
        if straight < 0:
            raise ValueError("长轴必须不小于短轴")
        angle = self.angle.value()
        loops = self.loops.value()
        points = await asyncio.to_thread(
            shape,
            center,
            "Stadium",
            straight + 2 * radius,
            2 * radius,
            angle,
            straight,
            radius,
            720,
        )
        if build != self.build_id:
            return
        route = Route(
            name="Track design",
            points=points,
            closed=True,
            metadata={
                "shape": "Stadium",
                "center": {"lat": center.lat, "lon": center.lon},
                "straight_m": straight,
                "radius_m": radius,
                "rotation_deg": angle,
                "laps": loops,
            },
        )
        self.c.set_position(center)
        self.c.commit(route)
        length = await asyncio.to_thread(lambda: RoutePath(route).length)
        self.stats.setText(
            f"单圈 {length:.3f} m\n总距离 {length * loops:.2f} m\n预计 {length * loops / self.c.config.data['speed_ms']:.1f} s\n旋转 {angle:.1f}° · {len(points)} 点"
        )
