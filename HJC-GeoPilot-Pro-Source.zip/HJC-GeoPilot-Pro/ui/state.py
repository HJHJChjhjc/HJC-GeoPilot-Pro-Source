from dataclasses import dataclass, field
from backend.models import Point, Route


@dataclass
class AppState:
    selected_device: str = ""
    route: Route = field(default_factory=Route)
    position: Point = field(default_factory=lambda: Point(28.68, 115.98))
    saved_position: Point | None = None
    preview: bool = True
