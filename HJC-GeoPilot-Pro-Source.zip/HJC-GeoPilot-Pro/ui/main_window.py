from __future__ import annotations
from PySide6.QtCore import QTimer
from PySide6.QtWidgets import (
    QMainWindow,
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QListWidget,
    QStackedWidget,
    QLabel,
    QComboBox,
    QCheckBox,
    QScrollArea,
)
from PySide6.QtGui import QShortcut, QKeySequence
from ui.controller import Controller
from ui.widgets.common import button, card
from ui.pages.devices_page import DevicesPage
from ui.pages.map_page import MapPage, MapPanel
from ui.pages.route_editor_page import RouteEditorPage
from ui.pages.track_page import TrackPage
from ui.pages.simulation_page import SimulationPage
from ui.pages.manual_page import ManualPage
from ui.pages.presets_page import PresetsPage
from ui.pages.diagnostics_page import DiagnosticsPage
from ui.pages.logs_page import LogsPage
from ui.pages.settings_page import SettingsPage
from ui.dialogs.about import show_about


class MainWindow(QMainWindow):
    def __init__(self, c: Controller) -> None:
        super().__init__()
        self.c = c
        self.allow_close = False
        self.last_key = None
        self.setWindowTitle("HJC GeoPilot Pro — Developed by Hjc / 由 Hjc 开发")
        self.resize(*c.config.data["window"])
        self.setMinimumSize(1120, 760)
        central = QWidget()
        self.setCentralWidget(central)
        outer = QVBoxLayout(central)
        outer.setContentsMargins(16, 12, 16, 8)
        body = QHBoxLayout()
        outer.addLayout(body, 1)
        sidebar, side = card()
        sidebar.setFixedWidth(202)
        brand = QLabel("HJC\nGeoPilot Pro")
        brand.setObjectName("brand")
        side.addWidget(brand)
        sub = QLabel("LOCATION LAB\n由 Hjc 开发")
        sub.setObjectName("subtitle")
        side.addWidget(sub)
        self.nav = QListWidget()
        self.nav.setStyleSheet("border:none;background:transparent;")
        self.nav.addItems(
            [
                "Home",
                "Devices",
                "Map",
                "Track Designer",
                "Route Editor",
                "Simulation",
                "Manual Control",
                "Presets",
                "Diagnostics",
                "Logs",
                "Settings",
            ]
        )
        side.addWidget(self.nav, 1)
        side.addWidget(button("About", lambda: show_about(self)))
        body.addWidget(sidebar)
        content = QVBoxLayout()
        body.addLayout(content, 1)
        top = QHBoxLayout()
        top.addWidget(QLabel("TARGET"))
        self.target = QComboBox()
        self.target.setMinimumWidth(220)
        top.addWidget(self.target, 1)
        self.preview = QCheckBox("Offline preview")
        self.preview.setChecked(True)
        top.addWidget(self.preview)
        self.connection = QLabel("No device connected")
        top.addWidget(self.connection)
        content.addLayout(top)
        self.stack = QStackedWidget()
        content.addWidget(self.stack, 1)
        self.pages = [
            SimulationPage(c, True),
            DevicesPage(c),
            MapPage(c),
            TrackPage(c),
            RouteEditorPage(c),
            SimulationPage(c),
            ManualPage(c),
            PresetsPage(c),
            DiagnosticsPage(c),
            LogsPage(c),
            SettingsPage(c),
        ]
        for page in self.pages:
            scroll = QScrollArea()
            scroll.setWidgetResizable(True)
            scroll.setWidget(page)
            self.stack.addWidget(scroll)
        self.nav.currentRowChanged.connect(self.navigate)
        self.nav.setCurrentRow(0)
        self.banner = QLabel("Ready · 可先编辑路线，再连接设备进行开发测试。")
        self.banner.setObjectName("banner")
        self.banner.setWordWrap(True)
        outer.addWidget(self.banner)
        footer = QHBoxLayout()
        footer.addWidget(QLabel("HJC GeoPilot Pro  ·  HJC Jiangke RUN Tool Pro"))
        footer.addStretch()
        label = QLabel("Developed by Hjc  ·  由 Hjc 开发")
        label.setObjectName("subtitle")
        footer.addWidget(label)
        outer.addLayout(footer)
        self.target.currentIndexChanged.connect(self.select_target)
        self.preview.toggled.connect(self.preview_changed)
        c.devices_changed.connect(self.update_targets)
        c.error.connect(self.show_error)
        c.message.connect(self.show_message)
        c.preset_loaded.connect(self.preset_loaded)
        self.save_shortcut = QShortcut(QKeySequence("Ctrl+S"), self)
        self.save_shortcut.activated.connect(lambda: c.launch(c.save_workspace()))
        self.undo_shortcut = QShortcut(QKeySequence("Ctrl+Z"), self)
        self.undo_shortcut.activated.connect(lambda: c.history_action())
        self.redo_shortcut = QShortcut(QKeySequence("Ctrl+Y"), self)
        self.redo_shortcut.activated.connect(lambda: c.history_action(True))
        self.status_timer = QTimer(self)
        self.status_timer.setInterval(500)
        self.status_timer.timeout.connect(self.refresh_selected)
        self.status_timer.start()
        self.update_targets()

    def navigate(self, index: int) -> None:
        self.stack.setCurrentIndex(index)
        if index == 7:
            self.c.launch(self.pages[7].refresh())
        page = self.pages[index]
        if isinstance(page, MapPanel):
            page.map.configure(page.map.center, page.map.zoom, page.map.map_type)

    def update_targets(self) -> None:
        selected = self.c.state.selected_device
        self.target.blockSignals(True)
        self.target.clear()
        for udid, info in self.c.devices.devices.items():
            self.target.addItem(f"{info.name} · iOS {info.ios}", udid)
        i = self.target.findData(selected)
        self.target.setCurrentIndex(i if i >= 0 else 0)
        self.target.blockSignals(False)
        if self.target.currentData():
            self.c.state.selected_device = self.target.currentData()
        self.refresh_selected()

    def select_target(self, index: int) -> None:
        self.c.state.selected_device = self.target.itemData(index) or ""
        self.c.config.data["last_device"] = self.c.state.selected_device
        self.c.schedule_save()
        self.refresh_selected()

    def preview_changed(self, checked: bool) -> None:
        self.c.state.preview = checked
        self.refresh_selected()

    def refresh_selected(self) -> None:
        info = self.c.devices.devices.get(self.c.state.selected_device)
        self.connection.setText(
            "Offline preview"
            if self.c.state.preview
            else info.connection
            if info
            else "Select a device"
        )
        key = self.c.key
        if key != self.last_key:
            self.last_key = key
            for page in self.pages:
                if isinstance(page, MapPanel):
                    page.map.trail = []
                    page.map.update()
            point = self.c.location.positions.get(key)
            if point:
                self.c.set_position(point)
        t = self.c.telemetry.get(key)
        if t:
            for index in (0, 5):
                self.pages[index].update_telemetry(key, t)
            # Do not continuously overwrite a manually set position after a finished run.
            run = self.c.simulation.runs.get(key)
            if run and run.task and not run.task.done():
                self.c.state.position = t.point
                self.c.position_changed.emit(t.point)

    def preset_loaded(self, preset) -> None:
        for page in self.pages:
            if isinstance(page, MapPanel):
                page.kind.setCurrentText(preset.map_type)
                page.map.configure(preset.center, preset.zoom, preset.map_type)

    def show_message(self, message: str) -> None:
        self.banner.setStyleSheet("")
        self.banner.setText(message)

    def show_error(self, message: str) -> None:
        self.banner.setText("⚠ " + message)
        self.banner.setStyleSheet("color:#ed5577;")

    def closeEvent(self, event) -> None:
        if self.allow_close:
            event.accept()
            return
        event.ignore()
        self.setEnabled(False)
        self.c.config.data["window"] = [self.width(), self.height()]
        self.c.launch(self.close_async())

    async def close_async(self) -> None:
        try:
            await self.c.shutdown()
        finally:
            self.allow_close = True
            self.close()
