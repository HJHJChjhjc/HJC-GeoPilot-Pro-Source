from PySide6.QtWidgets import QMessageBox, QWidget


def show_about(parent: QWidget) -> None:
    QMessageBox.about(
        parent,
        "About HJC GeoPilot Pro",
        "<h2>HJC GeoPilot Pro</h2><p>HJC Jiangke RUN Tool Pro</p>"
        "<p><b>Developed by Hjc<br>由 Hjc 开发</b></p>"
        "<p>iOS Location &amp; Route Simulation Toolkit</p>"
        "<p>Version 1.0.0 · WGS84 · Windows 10/11 x64</p>",
    )
