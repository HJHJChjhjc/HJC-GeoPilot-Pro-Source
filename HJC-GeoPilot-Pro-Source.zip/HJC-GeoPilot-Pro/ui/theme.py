from PySide6.QtCore import Qt
from PySide6.QtGui import QGuiApplication


def stylesheet(mode: str) -> str:
    dark = mode == "Dark" or (
        mode == "System" and QGuiApplication.styleHints().colorScheme() == Qt.ColorScheme.Dark
    )
    bg, card, text, muted, border = (
        ("#101720", "#1b2634", "#f4f7fb", "#9bafc4", "#2b3c50")
        if dark
        else ("#eef3f9", "#ffffff", "#172c44", "#657d96", "#dce5ef")
    )
    return f"""
    QWidget {{ color:{text}; font-family:"Segoe UI", "Microsoft YaHei UI", "Noto Sans CJK SC"; font-size:13px; }}
    QMainWindow, QDialog {{ background:{bg}; }}
    QWidget#page {{ background:{bg}; }}
    QFrame#card {{ background:{card}; border:1px solid {border}; border-radius:18px; }}
    QLabel#title {{ font-size:28px; font-weight:700; }}
    QLabel#subtitle {{ color:{muted}; font-size:13px; }}
    QLabel#metric {{ font-size:25px; font-weight:600; }}
    QLabel#brand {{ font-size:20px; font-weight:700; }}
    QLabel#banner {{ background:{card}; padding:10px; border-radius:8px; color:{muted}; }}
    QPushButton {{ background:{card}; border:1px solid {border}; border-radius:9px; padding:8px 14px; min-height:21px; }}
    QPushButton:hover {{ background:#d4e6fc; color:#17375d; border-color:#83b4f9; }}
    QPushButton:disabled {{ color:{muted}; }}
    QPushButton#primary {{ background:#377ff3; color:white; border:none; font-weight:600; }}
    QPushButton#danger {{ color:#ed5577; }}
    QLineEdit,QDoubleSpinBox,QSpinBox,QComboBox,QTextEdit,QPlainTextEdit {{ background:{card}; border:1px solid {border}; border-radius:8px; padding:7px; selection-background-color:#377ff3; }}
    QLineEdit:focus,QPlainTextEdit:focus {{ border:1px solid #377ff3; }}
    QComboBox::drop-down {{ border:none; width:20px; }}
    QComboBox QAbstractItemView {{ background:{card}; selection-background-color:#377ff3; }}
    QListWidget,QTableWidget {{ background:{card}; border:1px solid {border}; border-radius:12px; padding:6px; outline:none; }}
    QListWidget::item {{ padding:11px; border-radius:8px; }}
    QListWidget::item:selected {{ background:#377ff3; color:white; }}
    QHeaderView::section {{ background:{card}; padding:8px; border:0; color:{muted}; }}
    QProgressBar {{ background:{border}; border:none; border-radius:6px; min-height:12px; text-align:center; }}
    QProgressBar::chunk {{ background:#24bd98; border-radius:6px; }}
    QScrollArea {{ border:0; background:transparent; }}
    QScrollBar:vertical {{ width:8px; background:transparent; }}
    QScrollBar::handle:vertical {{ background:{border}; border-radius:4px; min-height:30px; }}
    QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical {{ height:0px; }}
    QCheckBox {{ spacing:7px; }}
    QToolTip {{ background:{card}; border:1px solid {border}; padding:5px; }}
    """
