from PySide6.QtWidgets import (
    QWidget,
    QVBoxLayout,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QFrame,
    QDoubleSpinBox,
    QAbstractSpinBox,
)


def button(text: str, callback, primary: bool = False) -> QPushButton:
    b = QPushButton(text)
    b.setObjectName("primary" if primary else "")
    b.clicked.connect(callback)
    return b


def row(*widgets) -> QHBoxLayout:
    layout = QHBoxLayout()
    layout.setSpacing(8)
    for w in widgets:
        layout.addWidget(w)
    return layout


def spin(
    value: float, minimum: float, maximum: float, suffix: str = "", decimals: int = 2
) -> QDoubleSpinBox:
    s = QDoubleSpinBox()
    s.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.NoButtons)
    s.setRange(minimum, maximum)
    s.setDecimals(decimals)
    s.setSuffix(suffix)
    s.setValue(value)
    return s


def card() -> tuple[QFrame, QVBoxLayout]:
    frame = QFrame()
    frame.setObjectName("card")
    layout = QVBoxLayout(frame)
    layout.setContentsMargins(18, 16, 18, 16)
    return frame, layout


class Page(QWidget):
    def __init__(self, title: str, subtitle: str) -> None:
        super().__init__()
        self.setObjectName("page")
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(24, 20, 24, 20)
        self.layout.setSpacing(14)
        t = QLabel(title)
        t.setObjectName("title")
        self.layout.addWidget(t)
        sub = QLabel(subtitle)
        sub.setObjectName("subtitle")
        sub.setWordWrap(True)
        self.layout.addWidget(sub)
