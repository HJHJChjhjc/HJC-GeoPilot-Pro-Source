from __future__ import annotations
import math
import logging
from collections import OrderedDict
from PySide6.QtCore import Qt, Signal, QPointF, QRectF, QUrl
from PySide6.QtGui import QPainter, QPen, QColor, QPixmap, QPainterPath
from PySide6.QtWidgets import QWidget
from PySide6.QtNetwork import QNetworkAccessManager, QNetworkRequest, QNetworkDiskCache
from backend.models import Point
from maps.projection import world, geographic
from maps.providers import PROVIDERS


class MapWidget(QWidget):
    clicked = Signal(object)
    point_moved = Signal(int, object)
    point_deleted = Signal(int)
    hovered = Signal(object)
    view_changed = Signal(object, int, str)
    position_moved = Signal(object)

    def __init__(self, cache_dir: str, parent: QWidget | None = None) -> None:
        super().__init__(parent)
        self.center = Point(28.68, 115.98)
        self.zoom = 16
        self.map_type = "Normal"
        self.points: list[Point] = []
        self.closed = False
        self.position: Point | None = None
        self.trail: list[Point] = []
        self.editable = False
        self.edit_position = False
        self.network = QNetworkAccessManager(self)
        cache = QNetworkDiskCache(self)
        cache.setCacheDirectory(cache_dir)
        cache.setMaximumCacheSize(150_000_000)
        self.network.setCache(cache)
        self.tiles: OrderedDict[tuple, QPixmap] = OrderedDict()
        self.pending: set[tuple] = set()
        self.failed: set[tuple] = set()
        self.network_message = ""
        self.setMouseTracking(True)
        self.setMinimumSize(300, 220)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.drag_index: int | None = None
        self.start_mouse: QPointF | None = None
        self.start_center = self.center
        self.moved = False

    def configure(self, center: Point, zoom: int, map_type: str) -> None:
        self.center = center
        self.zoom = max(2, min(19, zoom))
        self.map_type = map_type
        self.update()
        self.view_changed.emit(center, self.zoom, map_type)

    def set_route(self, points: list[Point], closed: bool = False) -> None:
        self.points = points.copy()
        self.closed = closed
        self.update()

    def fit(self) -> None:
        if not self.points:
            return
        raw = [world(p, 19) for p in self.points]
        scale = 256 * 2**19
        base = raw[0][0]
        xs = [base + (x - base + scale / 2) % scale - scale / 2 for x, y in raw]
        ys = [y for x, y in raw]
        self.center = geographic((min(xs) + max(xs)) / 2, (min(ys) + max(ys)) / 2, 19)
        span = max(
            (max(xs) - min(xs)) / max(100, self.width() - 90),
            (max(ys) - min(ys)) / max(100, self.height() - 90),
            1,
        )
        self.zoom = max(2, min(19, 19 - math.ceil(math.log2(span))))
        self.configure(self.center, self.zoom, self.map_type)

    def screen(self, point: Point) -> QPointF:
        cx, cy = world(self.center, self.zoom)
        x, y = world(point, self.zoom)
        size = 256 * 2**self.zoom
        dx = (x - cx + size / 2) % size - size / 2
        return QPointF(dx + self.width() / 2, y - cy + self.height() / 2)

    def coordinate(self, pos: QPointF) -> Point:
        cx, cy = world(self.center, self.zoom)
        return geographic(
            cx + pos.x() - self.width() / 2, cy + pos.y() - self.height() / 2, self.zoom
        )

    def request_tile(self, key: tuple) -> None:
        if key in self.pending or key in self.failed or len(self.pending) >= 16:
            return
        kind, z, x, y = key
        request = QNetworkRequest(QUrl(PROVIDERS[kind].url.format(z=z, x=x, y=y)))
        request.setRawHeader(b"User-Agent", b"HJC-GeoPilot-Pro/1.0 (desktop route testing)")
        request.setTransferTimeout(10000)
        self.pending.add(key)
        reply = self.network.get(request)

        def finished() -> None:
            self.pending.discard(key)
            if reply.error() == reply.NetworkError.NoError:
                pix = QPixmap()
                pix.loadFromData(reply.readAll())
                if not pix.isNull():
                    self.tiles[key] = pix
                else:
                    self.failed.add(key)
            else:
                self.failed.add(key)
                self.network_message = "底图不可用 · 坐标编辑仍可使用"
                logging.getLogger(__name__).debug("Tile request failed: %s", reply.errorString())
            while len(self.tiles) > 512:
                self.tiles.popitem(last=False)
            reply.deleteLater()
            self.update()

        reply.finished.connect(finished)

    def paintEvent(self, event) -> None:
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor("#172535"))
        cx, cy = world(self.center, self.zoom)
        left = cx - self.width() / 2
        top = cy - self.height() / 2
        n = 2**self.zoom
        for tx in range(math.floor(left / 256), math.ceil((left + self.width()) / 256)):
            for ty in range(math.floor(top / 256), math.ceil((top + self.height()) / 256)):
                if not 0 <= ty < n:
                    continue
                key = (self.map_type, self.zoom, tx % n, ty)
                rect = QRectF(tx * 256 - left, ty * 256 - top, 256, 256)
                if key in self.tiles:
                    painter.drawPixmap(rect.toRect(), self.tiles[key])
                else:
                    painter.setPen(QColor("#24394d"))
                    painter.drawRect(rect)
                    self.request_tile(key)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)

        def polyline(points: list[Point], color: str, width: int, closed: bool = False) -> None:
            if not points:
                return
            path = QPainterPath(self.screen(points[0]))
            for point in points[1:]:
                path.lineTo(self.screen(point))
            if closed:
                path.closeSubpath()
            painter.setPen(QPen(QColor(color), width))
            painter.setBrush(Qt.BrushStyle.NoBrush)
            painter.drawPath(path)

        polyline(self.points, "#408cff", 6 if self.map_type == "Route" else 4, self.closed)
        polyline(self.trail, "#41d7ab", 4)
        if self.editable:
            for i, point in enumerate(self.points):
                painter.setPen(QPen(QColor("#ffffff"), 2))
                painter.setBrush(QColor("#377ef4"))
                painter.drawEllipse(self.screen(point), 5, 5)
                if len(self.points) < 50:
                    painter.setPen(QColor("#131b26"))
                    painter.drawText(self.screen(point) + QPointF(8, -8), str(i + 1))
        if self.position:
            pos = self.screen(self.position)
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(44, 215, 171, 65))
            painter.drawEllipse(pos, 18, 18)
            painter.setPen(QPen(QColor("white"), 3))
            painter.setBrush(QColor("#11ba90"))
            painter.drawEllipse(pos, 8, 8)
        painter.setPen(QColor("white"))
        painter.fillRect(0, self.height() - 28, self.width(), 28, QColor(12, 20, 30, 205))
        painter.drawText(12, self.height() - 9, PROVIDERS[self.map_type].attribution)
        if self.network_message:
            painter.fillRect(0, 0, self.width(), 30, QColor(12, 20, 30, 205))
            painter.drawText(12, 20, self.network_message)
        painter.end()

    def mousePressEvent(self, event) -> None:
        self.start_mouse = event.position()
        self.start_center = self.center
        self.moved = False
        self.drag_index = None
        if self.editable:
            for i, p in enumerate(self.points):
                if (self.screen(p) - event.position()).manhattanLength() < 13:
                    if event.button() == Qt.MouseButton.RightButton:
                        self.point_deleted.emit(i)
                        self.start_mouse = None
                        return
                    self.drag_index = i
                    break
        if (
            self.edit_position
            and self.position
            and (self.screen(self.position) - event.position()).manhattanLength() < 20
        ):
            self.drag_index = -1

    def mouseMoveEvent(self, event) -> None:
        self.hovered.emit(self.coordinate(event.position()))
        if self.start_mouse is None:
            return
        delta = event.position() - self.start_mouse
        if delta.manhattanLength() > 3:
            self.moved = True
        if self.drag_index is not None:
            if self.drag_index == -1:
                self.position = self.coordinate(event.position())
            else:
                self.points[self.drag_index] = self.coordinate(event.position())
        else:
            x, y = world(self.start_center, self.zoom)
            self.center = geographic(x - delta.x(), y - delta.y(), self.zoom)
        self.update()

    def mouseReleaseEvent(self, event) -> None:
        if self.start_mouse is None:
            return
        if self.drag_index == -1:
            self.position_moved.emit(self.coordinate(event.position()))
        elif self.drag_index is not None and self.moved:
            self.point_moved.emit(self.drag_index, self.coordinate(event.position()))
        elif not self.moved and event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.coordinate(event.position()))
        elif self.moved:
            self.view_changed.emit(self.center, self.zoom, self.map_type)
        self.start_mouse = None
        self.drag_index = None

    def wheelEvent(self, event) -> None:
        before = self.coordinate(event.position())
        z = max(2, min(19, self.zoom + (1 if event.angleDelta().y() > 0 else -1)))
        self.zoom = z
        x, y = world(before, z)
        self.center = geographic(
            x - event.position().x() + self.width() / 2,
            y - event.position().y() + self.height() / 2,
            z,
        )
        self.configure(self.center, self.zoom, self.map_type)
