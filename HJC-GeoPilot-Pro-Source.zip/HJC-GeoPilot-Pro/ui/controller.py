from __future__ import annotations
import asyncio
import copy
import inspect
import logging
from dataclasses import asdict
from pathlib import Path
from collections.abc import Awaitable
from PySide6.QtCore import QObject, Signal, QTimer
from backend.config_manager import ConfigManager, atomic_json
from backend.device_manager import DeviceManager
from backend.location_service import LocationService
from backend.route_manager import RouteManager
from backend.route_engine import RouteHistory
from backend.preset_manager import PresetManager
from backend.simulation_service import SimulationService
from backend.tunnel_service import TunnelService
from backend.models import Point, Route, Telemetry
from ui.state import AppState


class Controller(QObject):
    preset_loaded = Signal(object)
    route_changed = Signal(object)
    position_changed = Signal(object)
    devices_changed = Signal()
    telemetry_changed = Signal(str, object)
    error = Signal(str)
    message = Signal(str)

    def __init__(self, config: ConfigManager, memory) -> None:
        super().__init__()
        self.config = config
        self.memory = memory
        self.state = AppState(
            position=Point.parse(config.data.get("manual_position", config.data["map_center"])),
            selected_device=config.data["last_device"],
        )
        self.history = RouteHistory(self.state.route)
        self.devices = DeviceManager()
        self.location = LocationService(self.devices)
        self.routes = RouteManager()
        self.presets = PresetManager(config.root / "configs")
        self.simulation = SimulationService(self.location, self.on_telemetry, self.on_run_error)
        self.tasks: set[asyncio.Task] = set()
        self.io_lock = asyncio.Lock()
        self.closing = False
        self.telemetry: dict[str, Telemetry] = {}
        self.save_timer = QTimer(self)
        self.save_timer.setSingleShot(True)
        self.save_timer.setInterval(600)
        self.save_timer.timeout.connect(lambda: self.launch(self.save_workspace()))
        self.refresh_timer = QTimer(self)
        self.refresh_timer.setInterval(6000)
        self.refresh_timer.timeout.connect(self.auto_refresh)
        self.refreshing = False
        self.manual_lock = asyncio.Lock()
        self.periodic_save = QTimer(self)
        self.periodic_save.setInterval(10000)
        self.periodic_save.timeout.connect(lambda: self.launch(self.save_workspace()))

    @property
    def key(self) -> str:
        return "preview" if self.state.preview else self.state.selected_device

    def launch(self, awaitable: Awaitable) -> asyncio.Task:
        async def guard() -> None:
            try:
                await awaitable
            except asyncio.CancelledError:
                raise
            except Exception as e:
                logging.getLogger(__name__).exception("Operation failed")
                self.error.emit(f"{type(e).__name__}: {e}")

        task = asyncio.get_event_loop().create_task(guard())
        self.tasks.add(task)

        def finished(done: asyncio.Task) -> None:
            self.tasks.discard(done)
            if (
                inspect.iscoroutine(awaitable)
                and inspect.getcoroutinestate(awaitable) == inspect.CORO_CREATED
            ):
                awaitable.close()

        task.add_done_callback(finished)
        return task

    async def initialize(self) -> None:
        try:
            path = self.config.root / "workspace.json"
            if self.config.data["restore_workspace"] and path.exists():
                route = await asyncio.to_thread(self.routes.load, path)
                self.commit(route)
        except Exception as e:
            self.error.emit(f"工作区恢复失败：{e}")
        if self.config.warning:
            self.error.emit(self.config.warning)
        if self.config.data["auto_refresh"]:
            self.refresh_timer.start()
        self.periodic_save.start()
        await self.refresh()

    def auto_refresh(self) -> None:
        if not self.refreshing and not self.closing:
            self.launch(self.refresh())

    async def refresh(self) -> None:
        if self.refreshing:
            return
        self.refreshing = True
        try:
            await self.devices.refresh()
            for udid, session in list(self.devices.sessions.items()):
                if not session.info.usb:
                    await self.simulation.stop(udid)
            self.devices_changed.emit()
            if self.devices.usb_error:
                self.message.emit(self.devices.usb_error)
        finally:
            self.refreshing = False

    async def connect(self, udid: str | None = None) -> None:
        udid = udid or self.state.selected_device
        if not udid:
            raise ValueError("请选择设备")
        try:
            await self.devices.connect(udid)
        finally:
            self.devices_changed.emit()
        self.config.data["last_device"] = udid
        self.schedule_save()

    async def disconnect(self, udid: str | None = None) -> None:
        udid = udid or self.state.selected_device
        await self.simulation.stop(udid)
        await self.devices.disconnect(udid)
        self.devices_changed.emit()

    async def reconnect(self) -> None:
        udid = self.state.selected_device
        await self.disconnect(udid)
        await self.connect(udid)

    async def start_tunnel(self) -> None:
        await TunnelService().start()
        await self.refresh()
        self.message.emit("tunneld 已就绪")

    def commit(self, route: Route) -> None:
        self.state.route = self.history.commit(route)
        self.route_changed.emit(self.state.route)
        self.schedule_save()

    def history_action(self, redo: bool = False) -> None:
        self.state.route = self.history.redo() if redo else self.history.undo()
        self.route_changed.emit(self.state.route)
        self.schedule_save()

    def set_position(self, point: Point) -> None:
        self.state.position = point
        self.position_changed.emit(point)
        self.schedule_save()

    def schedule_save(self) -> None:
        if not self.closing:
            self.save_timer.start()

    async def save_workspace(self) -> None:
        route = copy.deepcopy(self.state.route)
        settings = copy.deepcopy(self.config.data)
        settings["manual_position"] = asdict(self.state.position)
        settings["saved_position"] = (
            asdict(self.state.saved_position) if self.state.saved_position else None
        )
        async with self.io_lock:
            await asyncio.to_thread(
                atomic_json, self.config.root / "workspace.json", route.to_dict()
            )
            await asyncio.to_thread(atomic_json, self.config.path, ConfigManager.validate(settings))

    async def import_route(self, path: Path) -> None:
        route = await asyncio.to_thread(self.routes.load, path)
        self.commit(route)
        self.config.recent("recent_routes", str(path))
        self.message.emit(f"已导入 {route.name}")

    async def export_route(self, path: Path) -> None:
        await asyncio.to_thread(self.routes.save, path, copy.deepcopy(self.state.route))
        self.config.recent("recent_routes", str(path))
        self.schedule_save()
        self.message.emit(f"已保存 {path.name}")

    async def start(self, speed: float, loops: int, index: int, reverse: bool, hz: float) -> None:
        await self.simulation.start(
            self.key, copy.deepcopy(self.state.route), speed, loops, index, reverse, hz
        )

    async def manual(self, point: Point) -> None:
        key = self.key
        run = self.simulation.runs.get(key)
        if run and run.task and not run.task.done():
            raise ValueError("请先停止当前设备的路线模拟")
        async with self.manual_lock:
            if key != "preview":
                await self.location.set(key, point)
            self.set_position(point)

    async def manual_delta(self, east: float, north: float) -> None:
        from backend.geometry import offset

        key = self.key
        run = self.simulation.runs.get(key)
        if run and run.task and not run.task.done():
            raise ValueError("请先停止路线模拟")
        async with self.manual_lock:
            point = offset(self.state.position, east, north)
            if key != "preview":
                await self.location.set(key, point)
            self.set_position(point)

    def on_telemetry(self, key: str, value: Telemetry) -> None:
        self.telemetry[key] = value
        if key == self.key:
            self.state.position = value.point
            self.position_changed.emit(value.point)
        self.telemetry_changed.emit(key, value)

    def on_run_error(self, key: str, message: str) -> None:
        self.error.emit(f"{key}: {message}")

    async def shutdown(self) -> None:
        self.closing = True
        self.save_timer.stop()
        self.refresh_timer.stop()
        self.periodic_save.stop()
        others = [task for task in self.tasks if task is not asyncio.current_task()]
        for task in others:
            task.cancel()
        await asyncio.gather(*others, return_exceptions=True)
        await self.simulation.close()
        await self.devices.close()
        await self.save_workspace()
